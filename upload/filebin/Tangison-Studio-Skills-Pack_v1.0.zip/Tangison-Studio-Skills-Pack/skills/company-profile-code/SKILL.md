---
name: company-profile-code
description: Build multi-page A4 company profile documents as hand-coded HTML/CSS, rendered to a pixel-precise PDF via headless Chrome (Puppeteer). Use when the client wants exact control — real logos with backgrounds removed, real photography placed with true bleed, custom icon treatments, and pixel-accurate reproduction of a reference design — rather than AI-image-generated pages. Always process assets in the sandbox first, then build page-by-page HTML against a locked design system, then render and visually verify every page before delivery.
---

# Company Profile (Code / HTML)

This is the **coded** counterpart to the `company-profile` image-generation skill. Instead of asking an image model to render a page, this skill builds each page as real HTML/CSS and renders it to PDF with Chrome (via the `html-to-pdf` skill/Puppeteer script). The payoff: exact pixel positioning, real fonts, real transparent logos, real bleed — nothing "AI-interpreted."

Use this when the client gives you actual assets (logo files, photos, maybe a reference profile/flyer to rebuild) and wants precision, not a reinterpretation.

---

## Step 1 — Brainstorm & Intake (same as always, do this first)

- Who is the company, what's the profile for (pitch / investor / tender / general collateral)
- Page count and what each page covers (see page map below)
- Assets actually supplied: logo file(s), photography, a reference design to rebuild, brand guidelines
- Typography default: **Cabinet Grotesk** (headings) / **Satoshi** (body) / **JetBrains Mono** (metadata/labels) unless told otherwise
- Color system: pull real hex values from the brand, not guesses
- Visual tone default: editorial minimalism — asymmetric layout, one dominant element per page, real whitespace (see the `company-profile` skill's taste rules — they apply here too, just executed in code instead of an image model)

Confirm the page map with the client before writing any HTML.

---

## Step 2 — Asset Processing Pipeline (in the sandbox, before any HTML)

Every supplied asset gets prepared before it touches a layout. Do this work in the computer/sandbox, not by asking an image model to "clean up" the logo.

### Logo cleanup
- If the logo is a JPEG or a PNG with an unwanted background (white box, colored box), remove the background so it's a true transparent PNG:
  - For a flat/near-flat background color: color-key removal (Pillow/ImageMagick `-transparent` or `-fuzz X% -transparent color`)
  - For a busier background: use a proper background-removal tool (e.g. `rembg`) if available in the sandbox; fall back to manual masking in Pillow if not
  - Always verify the result has clean edges — no color fringe/halo around the mark — before using it
- Convert to PNG-24 with alpha if it isn't already
- Keep the original file untouched; save the cleaned version separately (e.g. `logo-transparent.png`) so you can regenerate if a step goes wrong

### Photography for full-bleed backgrounds
- Identify the focal point of the photo before cropping — don't just center-crop blindly
- Crop to the target page's aspect ratio (A4 portrait ≈ 210:297) at full output resolution, not a downscaled preview
- If the piece will print, extend the crop 3-5mm beyond the trim edge on all bleed sides so nothing white shows at the trim line
- Save a per-page cropped version rather than relying on CSS `object-fit` to do the cropping decision for you — CSS `background-size: cover` is fine for on-screen centering, but for a specific intentional composition, crop the source file itself

### Icon treatment
- If icons need a consistent circular/rounded-square shape with a border: don't recolor or redraw the icon — mask the actual supplied asset:
  - Circle: crop/mask to a square first, then apply `border-radius: 50%` on the containing element (with `overflow: hidden` and `object-fit: cover` on the image) — or bake the circular crop into the asset itself in the sandbox if the icon needs to be reused outside HTML too
  - Rounded-square: same idea with a smaller `border-radius`
  - Border ring: a wrapping element slightly larger than the icon, with `border: Npx solid <accent>` and matching border-radius, icon centered inside with even padding
- Keep icon treatment identical across the whole document — same size, same radius, same border weight — this is part of the locked design system, not a per-page decision

### Format/output hygiene
- Normalize all working images to a consistent color profile (sRGB) so colors don't shift between assets
- Keep a single `/assets` folder for the project with clear names (`logo-transparent.png`, `hero-page3.jpg`, `icon-services-01.png`) so the HTML references stay legible

---

## Step 3 — Reference Rebuild (when the client gives you an image to rebuild)

If asked to rebuild an existing flyer/profile page in code rather than design from scratch:

1. Look at the reference closely and extract, explicitly, before writing CSS:
   - The grid: how many columns, where the margins fall (in mm/px), where the safe zone is
   - Exact or near-exact hex values for every color used (sample them, don't eyeball)
   - The type pairing and approximate weights/sizes relative to the page
   - Where imagery bleeds vs. where it's contained
   - Logo size and placement relative to the page edges
2. Rebuild that structure in HTML/CSS as closely as proportions allow — this is a precision exercise, not a loose interpretation
3. If the reference contains a logo or graphic that's supplied separately as a real asset, use the real asset (after Step 2 cleanup) instead of trying to recreate it from the image
4. If something in the reference is a genuine illustration/graphic with no source file, recreate it as clean CSS/SVG rather than screenshotting or upscaling it

---

## Step 4 — Page Map

Same shape as the image-generation version of this skill — confirm with the client, adjust per company:

```
Page 1 — Cover: logo, one-line positioning statement, full-bleed or restrained visual
Page 2 — Who they are
Page 3 — What they do / services
Page 4 — How they work / process
Page 5 — Proof: portfolio, case studies, results
Page 6 — Team
Page 7 — Why them
Page 8 — Contact / closing
```

---

## Step 5 — HTML/CSS Build System

Follow the `html-to-pdf` skill's rendering rules exactly — they're what make the PDF pixel-precise instead of approximate.

### Document shell
- One HTML file for the whole profile, one `.page` block per page, `page-break-after: always` between them
- `html, body` sized to `210mm` × `297mm`, **no background on `html`/`body`** — backgrounds go on the `.page` container, or you get phantom extra pages
- **Always render at `scale=1.0`.** Never shrink via `--scale` to force-fit content — fix font sizes/spacing in CSS instead. Scaling below 1.0 causes offset content and clipped text, especially with full-bleed images and any RTL text.

```css
@page { size: A4; margin: 0; }

html, body {
  width: 210mm;
  height: 297mm;
  margin: 0;
  padding: 0;
  overflow: hidden;
}

.page {
  width: 210mm;
  height: 297mm;
  position: relative;
  page-break-after: always;
  overflow: hidden;
  box-sizing: border-box;
  background: #f7f8fa; /* background goes on the page container, never on body */
}

.page:last-child { page-break-after: auto; }
```

### Design system as CSS variables (locked once, reused every page)
```css
:root {
  --color-bg: #FFFFFF;
  --color-ink: #111315;
  --color-accent: #2CB5B4;
  --font-heading: 'Cabinet Grotesk', sans-serif;
  --font-body: 'Satoshi', sans-serif;
  --font-mono: 'JetBrains Mono', monospace;
  --margin: 18mm;
  --grid-gap: 8mm;
}
```
Every page pulls from these variables. If a page needs to break the grid deliberately (full-bleed image, oversized pull-quote), that's a conscious layout decision on top of the locked system, not a departure from it.

### Full-bleed images
```css
.hero-bleed {
  position: absolute;
  inset: 0;               /* fills the entire .page, true edge-to-edge bleed */
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center; /* adjust per-image based on the focal point from Step 2 */
}
```
Use the pre-cropped asset from Step 2, not an arbitrary source photo with `object-fit` guessing the crop for you.

### Logo placement
```css
.logo {
  position: absolute;
  top: var(--margin);
  left: var(--margin);   /* or wherever the page composition calls for it */
  width: 32mm;           /* fixed real-world size, consistent across the document unless a page calls for a deliberately larger cover-page logo */
  height: auto;
}
```
Always the cleaned transparent PNG from Step 2. Never place a logo still sitting on its original background box.

### Icon treatment (circular with border, as an example)
```css
.icon-ring {
  width: 20mm;
  height: 20mm;
  border-radius: 50%;
  border: 1.5px solid var(--color-accent);
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
}
.icon-ring img {
  width: 70%;
  height: 70%;
  object-fit: contain;
}
```

### Typography
```css
h1 { font-family: var(--font-heading); font-weight: 700; }
p, li { font-family: var(--font-body); font-weight: 400; }
.meta, .page-number, .url { font-family: var(--font-mono); font-size: 8pt; letter-spacing: 0.02em; }
```
Load real web fonts (`@font-face` or a hosted font source) and wait for `document.fonts.ready` before rendering — the `html-to-pdf` script already does this, but if fonts still render as a fallback, increase `--wait`.

---

## Step 6 — Render

Use the `html-to-pdf` skill's script:

```
node scripts/html-to-pdf.js profile.html profile.pdf --format=A4 --margin=0 --expect-pages=<N>
```
- `--margin=0` because margins are handled inside the CSS (`--margin` variable), not by Puppeteer's page margin
- `--expect-pages=<N>` set to the real page count so overflow is caught automatically
- Never drop `scale` below 1.0 to force a fit — if a page overflows, fix that page's HTML (font size, spacing, image crop), not the render scale

---

## Step 7 — Visual Verification (mandatory, not optional)

After rendering:
1. Convert the PDF to page images and actually look at every page (e.g. `pdftoppm profile.pdf page -png`, then view each PNG)
2. Check per page:
   - No overflow: no empty trailing page, no content pushed onto an extra page
   - No horizontal cut-off: nothing clipped at the left/right edge
   - Logo is the clean transparent version, correctly placed, undistorted
   - Full-bleed images actually bleed to the edge with no white sliver
   - Icon treatments are consistent (same size, same radius, same border) across every page they appear on
   - Fonts rendered as real fonts, not a fallback substitute
   - Colors match the locked palette exactly
3. If anything fails, fix the HTML/CSS for that page specifically and re-render — don't rebuild the whole document over one broken page
4. Max 5 fix attempts per page before stopping and flagging the specific unresolved issue rather than shipping a broken PDF

---

## Step 8 — Deliver

Only hand over the PDF after every page has passed visual verification. Keep the `/assets` folder and the HTML source alongside the PDF so the client (or a future edit request) can regenerate from source rather than needing the whole document rebuilt from scratch.

---

## Default Formula

**Hand-coded HTML/CSS → Puppeteer render at scale=1.0 → real cleaned assets (transparent logo PNGs, pre-cropped bleed photography, masked icon treatments) → locked CSS-variable design system → per-page visual verification before delivery.**
