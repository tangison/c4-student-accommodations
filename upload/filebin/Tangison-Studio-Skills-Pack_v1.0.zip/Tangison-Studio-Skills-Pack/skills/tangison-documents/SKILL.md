---
name: tangison-documents
description: Create premium, print-ready business and editorial documents for Tangison Technologies CC, Tangison Studio, Tangison Labs, and Studio's clients — quotations, invoices, proposals, business plans, financial projections, letters, agreements, NDAs, reports, certificates, briefs, statements of work, minutes, receipts, policy manuals, branded forms, brand books, brochures, case studies, portfolios, lookbooks, and magazine-style features. Use whenever a document must be intentionally written and art-directed, carry the correct Tangison entity and legal details, use authentic logos, remain print-friendly, and pass visual inspection before delivery.
---

# Tangison Document & Editorial Production

Write and design like an experienced human professional — never a generic template with text dropped into boxes. Two decisions come before layout: which entity issues the document, and flow vs editorial production. Decide both first.

## Entity routing

| Entity | Use for | Key facts | Fine print |
|---|---|---|---|
| **Technologies** (legal issuer) | Letters, NDAs, contracts, business plans, formal reports, policy manuals, certificates | Reg. CC/2026/10147, incorp. 20 Aug 2026; 47 Corner Dr. Frans Indongo St. & John Meinert St., Windhoek West; PO Box 1662, Windhoek; info@tangison.com | Registration number must appear somewhere on the document |
| **Studio** (trading identity) | Quotations, invoices, proposals, client creative/web work | Trading name of Tuppaman Investment CC (Reg. CC/2024/09945); studio@tangison.com · +264 85 341 1522 · studio.tangison.com; bone `#F6F4EF`/white/Atlantic black `#111315`/Signal Teal `#2CB5B4` only; Cabinet Grotesk + Satoshi + JetBrains Mono | "A trading name operating under Tangison Technologies CC (Reg. CC/2026/10147)" — never present as its own registered entity |
| **Labs** (applied R&D) | R&D proposals, technical docs | `#FAFAF8`/`#1A1A1A`/`#6B6860`, Rust `#C4562A` primary + Teal `#2CB5B4` secondary; Satoshi + Cabinet Grotesk + JetBrains Mono; zero border-radius, no exceptions | Same Technologies disclosure as Studio |

If unclear which entity, ask before producing anything.

## Format routing

**Flow-PDF (default):** quotations, invoices, letters, agreements, NDAs, reports, briefs, SOWs, minutes, receipts, most business plans/financials, text-heavy profiles. Real paragraphs, tables, pagination.

**Editorial/visual:** brand books, brochures, case studies, portfolios, lookbooks, visual proposals, magazine features, client-facing visual profiles.

Company profiles can go either way — always ask which fits, never default silently.

## Before building, collect

Document type + format track · purpose + reader · issuing entity · form of address/subject · required facts/figures/dates · language · supplied logos/photos/signatures · signatory · payment relevance · print vs digital vs both.

Ask one question at a time, only when it would materially change the result. Never invent registration numbers, testimonials, awards, partners, addresses, qualifications, results, guarantees, timelines, or contact details.

## Editorial production

**Interview first** (even if the request looks complete): output (page images/PDF/both), format/size, page count (cover counted?), content source (supplied/rewritten/developed-from-facts), imagery source, character (quiet premium/bold editorial/warm/formal/technical/heritage).

**Modes:**
- **A — Individual pages.** One page at a time: build, inspect, correct, continue. Never one contact sheet. Flat straight-on artwork, no mockups/perspective/shadows. Exact aspect ratio. PNG export; PDF only if asked.
- **B — Composed PDF.** For long reports, exact tables/charts, formal contents, frequent revisions. Real text flow, proper grids/master pages. HTML/CSS only if it simplifies and renders exactly. Render every page to check before delivery.
- **C — Hybrid.** Visual base (photography/textures/illustration) generated separately; logos and final text placed deterministically over it — image generation never has authority over spelling, numbers, logos, or dense copy.

Short visual profile → Mode A. Substantial exact text → Mode C.

**Exact-text protocol:** lock a page-copy ledger before producing visuals (role, headline, subheadline, metadata, footer, character count, entity, logo, image source) for any long or sensitive document.

**Logo consistency:** same rules as flow documents, confirmed per page in the ledger — one confident opening placement, one small signature/watermark per internal page, never two large treatments on one page.

**Inspection:** render full resolution, match the ledger exactly, build a contact sheet, check logo/crop/colour/overflow per page, correct and re-render — then the shared QC/Delivery rules below apply.

## Art direction (decide before layout)

Character · one-sentence visual idea tying design to entity/purpose · grid (single column/asymmetric split/editorial columns/modular ledger/wide-margin legal/ceremonial axis) · cover treatment · logo rhythm · motif · print mode (ink-light/standard/presentation-rich).

## Cover logic

Use for: proposals, business plans, financial reports, profiles, audits, policy manuals, long reports, major agreements, certificates. Usually omit for: invoices, receipts, short quotations, letters, minutes, compact SOWs. Don't default to centred — asymmetric, lower-corner lockup, vertical margin title, split field, oversized cropped icon, or a large quiet field with a small confident logo all work; a minimal cover still needs real tension.

## Logo system

**Opening page:** one confident placement (top/bottom/asymmetric field/margin/large pale symbol).
**Internal pages:** one of — small header/footer logo, icon beside page number, monochrome signature, subtle watermark, cropped icon in a margin, blind-emboss outline. Never two large treatments on one page.
**Watermarks:** ghost logo, edge-cropped icon, low-opacity wordmark, outline mark, pale mark behind a title, fragment in a margin. Opacity 3–6% behind text, 7–12% empty areas, up to 18% outline-only — judge from the render. Never behind body text/tables/figures/clauses/signatures/forms. ~30–60% of internal pages by default; every page only if asked. Vary position/scale/treatment.
**Integrity:** preserve aspect ratio; prefer SVG/transparent PNG; never fabricate, redraw, or recreate the mark with image generation; never crop the full wordmark (the mast icon alone is the only standalone-safe crop). No verified logo → request or omit it.

## Layout variation

1–2 pages: one layout family, hierarchy changes only. 3–5 pages: 2+ families. 6+ pages: 3+ families. A colour change or repeated card grid is not variation. Families: asymmetric masthead, quiet financial ledger, editorial split, evidence board, chapter-opening field, wide-margin legal, data-led page, dominant image + structured text, ceremonial axis, contact-focused closing page. Before a multi-page build, assign every page: purpose, dominant idea, layout family, logo treatment, watermark decision, density, known risk.

## Typography

Poppins for Technologies/general Studio docs (Studio's own web brand uses Cabinet Grotesk/Satoshi/JetBrains Mono — match whichever entity is routed). Body 9–10.5pt, supporting 8–9pt, labels 8–9pt bold/medium, headings 11–15pt bold. Never below 7.5pt. No bolded paragraphs, no rivers from narrow-column justification. Client documents use the client's own brand fonts or a close installed substitute.

## Banking (Studio-issued only)

FNB Namibia · TANGISON, Gold Business Account · Acc 64291690038 · Branch John Meinert St. (280872) · Swift FIRNNANX · eWallet 081 341 1522. Only on quotations/proforma invoices/invoices/receipts/paid SOWs — never on proposals, letters, profiles, reports, certificates, NDAs, policy manuals, general agreements.

## Contact & signature defaults

Technologies: info@tangison.com · tangison.com. Studio: studio@tangison.com · +264 85 341 1522 · studio.tangison.com.

```
Tangi
Tangison Studio
Creative Digital Agency
+264 85 341 1522
studio@tangison.com
```
Swap in the Technologies line for parent-entity legal documents. Override only when explicitly instructed.

## Client branding

Client's brand leads — no forced Tangison colours/type. Omit Tangison branding unless requested (a small "produced by Tangison Studio" credit is fine if agreed). Real client logo, verified colours, accessible contrast, no random gradients or improvised white boxes behind logos.

## Print-friendly design

Ink-light by default for quotations/invoices/letters/agreements/NDAs/policy manuals/plans/financials: light pages, dark text, thin rules, pale callouts, minimal fills. Avoid dark pages, saturated table headers, heavy borders, ink-wasting decoration. Must read fine in grayscale. Presentation-rich styling only for primarily-digital or visual-impact documents.

## Page numbering & signatures

`Page X of Y`; decide if covers count. Legal/financial/policy/admin docs number every page. Keep numbering clear of content/signatures/trim. Signature blocks (name, position, signature, date, org, witness, stamp as needed) stay together, never split across pages, no watermark behind them.

## Document routing quick table

| Type | Entity | Notes |
|---|---|---|
| Quotation | Studio | 1–3pp, no cover, scope table, validity/assumptions/exclusions, Technologies reg. in fine print |
| Proforma/Invoice | Studio | 1–2pp, no cover, verify all math, no VAT without confirmation, no imagery unless asked |
| Proposal | Any, per purpose | 2–6pp, editorial cover, payment info only for formal commercial offers |
| Partnership proposal | Shared | Balance both logos, neutral motif, responsibilities/value/implementation/governance/next steps |
| Company profile | Per format routing above | Confirm flow vs editorial first |
| Business plan | Technologies | Cover, doc control, contents, exec summary through risks; distinguish fact/assumption/estimate/projection |
| Financial projections | Any | Recalculate totals, state currency, label assumptions, repeat headers after breaks |
| Report/audit | Technologies | Evidence-led, captioned images, findings ≠ implications ≠ recommendations |
| Contract/NDA | Technologies | Wide margins, clause numbering, defined terms, reg. + registered office on first page |
| Letter | Per purpose | No cover, primary logo page one, `Page X of Y`, signature |
| Policy manual | Technologies | Cover, doc control, approvals, version/effective/review dates |
| Certificate | Technologies | One ceremonial page, recipient name dominant, not overcrowded |

## Writing standards

Concrete nouns, active verbs, natural Namibian business English where relevant, varied sentence length, no em dashes, no generic AI phrasing ("in today's fast-paced world," "leveraging cutting-edge technology," "unwavering commitment," etc.). Replace vague claims with facts/dates/quantities/evidence. Never invent registration numbers, testimonials, awards, partners, addresses, qualifications, results, guarantees, timelines, or financial performance.

## Figures & accuracy

Verify every quantity, price, subtotal, tax, deposit, payment stage, balance, and total. Label notes accurately (Estimate/Assumption/Excludes/Payment milestone/Validity/Projection note/Risk note/Source). `N$`/`NAD` consistently. No VAT without confirmation.

## Image rules

Preserve aspect ratio, never stretch, never low-res logos, caption evidence images/charts, prefer real supplied images, never generate replacements for official marks, no stock filler, check crops carefully for faces/products/identifying details.

## PDF construction

Flow-based layout for text/tables/lists/signatures/pagination; page-level drawing only for watermarks/backgrounds/folios/borders/motifs. Keep headings with their content, signatures together, repeat table headers after breaks. Never shrink content to hit a page count — edit or add a page.

## Mandatory QC (every document)

Confirm page size/orientation → render every page at high res → confirm render count matches page count → contact sheet → inspect each page (edges, tables, logos, watermarks, signatures, footers, numbering; ledger match for editorial) → correct → re-render and re-inspect → deliver only the corrected version.

Reject if: wrong size; clipped text/tables; footer collision; stranded heading; split signature block; distorted/blurry/recoloured/trim-crowded logo; unreadable watermark; wrong numbering; missing/duplicated content; blank page; text too small; generic-looking cover; repeated layout without purpose; looks AI-generated or unfinished; wastes ink unnecessarily. Never claim completion before visual inspection.

## Delivery

Clear filename, working files kept separate from finals. Deliver the final PDF (or page set), a contact-sheet preview when useful, a brief design-direction note, and any remaining assumptions. No generation commentary inside the document itself.
