---
name: tangison-market-audit
description: Competitor audit plus local SEO baseline for a client, in Namibian context. Use for pitches, the Refresh track of the client handover pack, and any "how do we compare locally" request. Evidence first, no invented numbers.
---

# Tangison Market Audit

Inputs: client name, website, town, services, 3 to 5 named competitors. If no competitors are given, find them with web search for the client's service plus town, and list who you picked and why.

1. Competitor snapshot. For each competitor record only what you can see: website, offer, public prices, social channels and posting rhythm, Google Business Profile (found or not, rating, review count), WhatsApp contact shown, page speed feel on mobile. Every row carries source URL and date.
2. Client baseline. Same fields for the client, plus: is the site indexed, Search Console connected, sitemap present, meta titles and descriptions, LocalBusiness schema, NAP (name, address, phone) consistent everywhere.
3. Local SEO check. Google Business Profile: categories, hours, photos, services, reviews, replies. Local keywords: service plus town, service plus "near me", Namibian spellings. Directories: research which ones matter locally before listing any.
4. Gaps and quick wins. Rank by effort against impact. Separate what is fixable this week from 30, 60 and 90 day work.
5. Scorecard. Give the client's baseline numbers (rating, reviews, indexed pages, keywords ranked if known) so the 90-day review has a starting point. Unknown means "not measured", never a guess.
6. Output. A one page summary in plain language, plus the evidence table. Use the client's brand from the site build. Handover Refresh track pulls from this file.

Rules: label every claim as fact, source-supported, or assumption. Never invent rankings, traffic or competitor revenue. Follow tangison-scraping rules if crawling: robots.txt, no logins. Namibian context (N$, +264). No em dashes. If the audit is for a pitch, no criticism of a named competitor beyond what is publicly verifiable.
