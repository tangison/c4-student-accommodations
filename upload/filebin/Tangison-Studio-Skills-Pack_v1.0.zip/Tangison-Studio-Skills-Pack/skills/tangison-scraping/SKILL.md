---
name: tangison-scraping
description: Build and run web scrapers and crawlers using the Scrapling Python library — single-page fetches, anti-bot/Cloudflare bypass, full multi-session crawls, and RAG-ready Markdown extraction. Use whenever the task is building a scraper, spider, or data-collection script as part of a project (client data migration, competitor/market monitoring, content extraction), not for one-off lookups inside a chat session — those use web_search/web_fetch directly. Also covers when a target site needs stealth, JS rendering, or resilience to layout changes.
---

# Tangison Scraping (Scrapling)

## Where this applies

This skill is for **local/Claude Code work** — building an actual scraper as a deliverable or internal tool, where the execution environment has full internet access. It does not apply to gathering information inside a chat session; that goes through the built-in web_search/web_fetch tools, which already exist for that and don't need a library installed. Don't reach for Scrapling to answer a one-off question — reach for it when the deliverable *is* a scraper, or when a project needs repeatable, scheduled, or large-scale extraction.

## Choosing the right fetcher tier

Start at the lightest tier that works; escalate only when the site demands it.

1. **`Fetcher`** — plain HTTP requests, can impersonate browser TLS fingerprint/headers, supports HTTP/3. Use first for anything without heavy JS rendering or bot protection.
2. **`DynamicFetcher`** — full browser automation (Playwright Chromium or Google Chrome) for JS-rendered content. Use when the data isn't in the initial HTML response.
3. **`StealthyFetcher`** — fingerprint-spoofing, bypasses Cloudflare Turnstile/Interstitial and similar anti-bot systems. Use only when the target actively blocks the lighter tiers — it's the heaviest option and should be a last resort, not a default.

For a full crawl rather than a single fetch, use the `Spider` class (Scrapy-like API: `start_urls`, async `parse()`, `Request`/`Response`) instead of looping fetcher calls manually — it brings concurrency limits, per-domain throttling, pause/resume, and streaming for free.

## Resilience and correctness

- **Adaptive selectors**: use `auto_save=True` on first scrape, `adaptive=True` on later runs so element-finding survives site redesigns instead of breaking silently. Prefer this over hardcoded brittle selectors for anything that will run more than once.
- **Development mode**: cache responses to disk on first run, replay on later runs while iterating on `parse()` logic — avoids re-hitting the target server every time a parsing bug is fixed. This is the scraping-specific form of the systematic-debugging discipline: reproduce once, then iterate against the captured evidence rather than guessing against a live site.
- **Blocked-request detection**: let Scrapling's automatic detection and retry handle transient blocks rather than hand-rolling retry logic.
- **AutoThrottle**: let it tune delay per domain from response speed and back off on rate-limiting/blocking signals, rather than picking an arbitrary fixed delay.

## Respect the target

- **Honor `robots_txt_obey`** unless there's a specific, stated reason not to for a given job — Disallow, Crawl-delay, and Request-rate directives, per-domain cached.
- Check the target's terms of service before scraping at scale; some sites explicitly prohibit it regardless of robots.txt.
- Never scrape to reproduce copyrighted content wholesale (articles, images, datasets under license) — extract facts and structured data, not a republished copy. This follows the same copyright discipline already in place for research and document work.
- Don't scrape behind authentication or a paywall without the account holder's explicit authorization for that use.
- Rate-limit deliberately even where technically possible to go faster — a scraper that degrades someone else's production site is a bug, not a feature.

## Output and export

Use the built-in exporters (`to_json()`, `to_jsonl()`, `to_csv()`, `to_xml()`) rather than hand-writing serialization. For feeding scraped content into research or documentation work, `page.markdown()` (or the `SiteToMarkdownSpider` template for a whole site) produces clean, sanitized Markdown without needing an LLM in the loop — use this ahead of `tangison-research`'s General Research mode when the source is a site rather than a search result.

## Deliverable completeness

A scraper delivered as a project artifact follows the same standard as everything else here: full working code for every requested target/field, not a skeleton with "add more selectors as needed" — see `tangison-full-output-enforcement`. If a selector or fetch genuinely breaks and the fix isn't obvious, that's a `tangison-systematic-debugging` situation (reproduce with dev-mode caching, trace why the selector stopped matching, fix the root cause) rather than a guess-and-retry loop.

## Setup reference

```bash
pip install "scrapling[fetchers]"
scrapling install           # downloads browsers + fingerprint deps
```

Extras: `scrapling[ai]` for the MCP server, `scrapling[rag]` for RAG-pipeline helpers, `scrapling[shell]` for the interactive scraping shell, `scrapling[all]` for everything. A Docker image with every extra and browser preinstalled is available at `pyd4vinci/scrapling` or `ghcr.io/d4vinci/scrapling:latest`.

Minimal single-page fetch:

```python
from scrapling.fetchers import StealthyFetcher

StealthyFetcher.adaptive = True
page = StealthyFetcher.fetch('https://example.com', headless=True, network_idle=True)
items = page.css('.product', auto_save=True)
```

Minimal crawl:

```python
from scrapling.spiders import Spider, Response

class MySpider(Spider):
    name = "demo"
    start_urls = ["https://example.com/"]

    async def parse(self, response: Response):
        for item in response.css('.product'):
            yield {"title": item.css('h2::text').get()}

MySpider().start()
```
