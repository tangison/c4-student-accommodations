---
name: tangison-research
description: Deep, cited research delivered as a written report, in two modes — general web/market/technical research synthesized from primary sources, or focused reproduction of an AI/code repository's documented results with auditable evidence. Use whenever the request needs rigorous multi-source research written up with citations (not a quick lookup or top-N list), or wants a repo's README-documented setup faithfully run and the outcome recorded. Ask which mode fits if it's unclear, and don't reach for this on a request answerable with a short search.
---

# Tangison Research

Two distinct jobs live here. Pick the right one before starting; don't blend them.

## Mode selection

- A market, technical, comparative, or investigative question best answered by synthesizing multiple sources → **General Research mode**.
- The request centers on an actual code repository with a README, scripts, or documented commands, and the goal is verifying it runs and matches its claims → **Repo Reproduction mode**.
- A quick lookup, single fact, or top-N list needs neither — handle it as an ordinary search, don't invoke this skill for it.

## General Research mode

### Scope first

Unless already specified, ask one short question: "How long do you want this research task to run?" Map the answer to a depth tier:

- A few minutes → **Quick**: 3–5 search queries, 5–10 sources.
- ~10–15 minutes → **Thorough**: 5–10 queries from different angles, 15–25 sources.
- Longer / no limit → **Exhaustive**: 10+ queries, 25+ sources, including primary sources, expert views, and contrarian sources.

If the topic itself is unclear, ask at most 1–2 more concise questions (the topic, or a critical angle/source constraint), then proceed once scope is set.

### Primary sources first

Investigate against primary sources — official docs, source code, specs, first-party APIs, original filings — not a secondary write-up of them. Follow every claim back to the source that owns it. Avoid re-scraping a URL already returned with full content from an earlier search.

### Parallel angles (Thorough / Exhaustive)

Split by angle where it helps: overview and definitions, technical or implementation detail, market and industry context, contrarian views/risks/limitations, primary sources and official docs. Each angle should surface claims, source URLs, source-quality notes, and uncertainty — not just a summary.

### Deliverable

Write findings to a single Markdown file. If the workspace already keeps research notes somewhere, match that convention; if there's none, pick a sensible location and say where. Default structure:

```
# Deep Research: [Topic]

## Executive Summary
## Key Findings          (numbered, each with a source link)
## Detailed Analysis
## Contrarian Views and Risks
## Open Questions
## Sources                (every URL used, one-line note each)
## Rerun Inputs            (topic / depth / output format — so this run can be repeated)
```

### Quality bar

Cite sources for every factual claim. Prefer primary sources when available. Flag uncertainty and conflicting evidence explicitly rather than smoothing it over. Synthesize — don't hand back a list of scrape summaries.

## Repo Reproduction mode

Use when the target is an AI/ML or software repository with a README, scripts, or documented commands, and the goal is a small, honestly-verified reproduction — not open-ended experimentation, and not "make it run by changing whatever's necessary."

### Trusted target selection

Choose the smallest target that honestly demonstrates the repo does what it documents, in this order of preference: documented inference → documented evaluation → documented training startup or partial verification → full training only after explicit confirmation.

Treat the README as the primary intent. Use other repo files to clarify it, never to silently override it. If the README and any accompanying paper conflict, record the conflict rather than picking one silently.

### Workflow

1. Read the README and repo signals; extract documented commands and candidate targets.
2. Select and state the minimum trustworthy target, and why.
3. Set up only the target-specific environment, checkpoint, or dataset assumptions actually needed.
4. Run the documented command for that target.
5. Pause for explicit confirmation before anything meaning fuller training, or any change that could alter dataset, split, checkpoint, preprocessing, metric, loss, or result interpretation.
6. Write the outputs below and give a concise final summary.

### Patch boundary

Prefer no repository edits. If something must change to run: try command-line arguments, environment variables, path fixes, or dependency-version fixes before touching code. Any applied fix must be disclosed — what changed, why it was necessary, whether it alters functional or scientific meaning, and whether it affects comparability with the README's claims. Never touch model architecture, core logic, or experiment meaning just to force a run through.

### Outputs (one folder, e.g. `repro_outputs/`)

- **SUMMARY.md** — shortest high-value summary.
- **COMMANDS.md** — copyable commands actually run.
- **LOG.md** — process evidence, assumptions, failures, decisions.
- **COMPARABILITY_REPORT.md** — deviations from the README's documented protocol and what they mean for comparing results.
- **PATCHES.md** — only if a repo file was changed; what and why.

Distinguish verified facts (you ran it, you saw the output) from inferred guesses (you're reasoning from reading the code) everywhere in these files — never blur the two together.

## What didn't make the cut

Left out on purpose: the multi-skill orchestration layer the source material for this mode assumed — separate skills for repo intake, environment bootstrap, candidate-exploration campaigns, sweep ranking, a personal-rigor preference file, an automatic lessons-store script. That machinery depends on a whole sub-skill ecosystem and script bundle that doesn't exist in this environment; porting the names without the infrastructure behind them would just leave dangling references that fail silently. If exploratory/candidate ML research — trying variants, ranking ideas, running sweeps — becomes a recurring need, that's worth building as its own skill properly rather than bolting on as an unsupported mode here.
