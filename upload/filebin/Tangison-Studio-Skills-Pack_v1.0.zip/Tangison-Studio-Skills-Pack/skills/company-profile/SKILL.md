---
name: company-profile
description: Design and produce multi-page A4 company profile documents (client-facing, editorial, magazine-quality). Use for corporate profiles, capability decks, pitch documents, investor-facing profiles, and tender submissions. Always brainstorm and map the full page set with the client before generating anything. Output must read like a designed editorial document — bespoke layout, restrained typography, deliberate whitespace — never like a generic AI template.
---

# Company Profile

A company profile is not a slide deck with borders. It is an **editorial document** — the kind a real design studio would lay out page by page, with a point of view. The bar is: *this looks like it came out of a design agency, not out of a template picker.*

If a page could be mistaken for a default Canva template or a generic "corporate deck" layout, it has failed. Every page needs a reason for its composition.

---

## Step 1 — Brainstorm & Intake (always first, no exceptions)

Never generate a page before this is done. Establish with the client:

1. **Who is this company, really** — not just the industry, but what makes them worth reading three pages about. What's the one thing this profile needs the reader to believe by the last page?
2. **Purpose** — client pitch, investor deck, tender submission, general brand collateral. This changes tone: a tender is restrained and factual; a pitch can have more personality.
3. **Assets supplied** — logo files, photography, product shots, team photos, existing profile to rebuild. Use exact supplied assets — never regenerate a logo or invent photography style that clashes with real supplied photos.
4. **Page count and content** — how many pages, what goes on each (see Step 2).
5. **Typography** — default to **Cabinet Grotesk** (headings) / **Satoshi** (body) / **JetBrains Mono** (metadata, page numbers, URLs) unless the client's brand dictates otherwise or they state a preference.
6. **Color system** — pull from the client's actual brand palette. Default restraint: one dominant neutral (black or a deep brand tone), white or off-white ground, one accent color used sparingly and with intent — never decoratively.
7. **Visual tone** — default is **editorial minimalism**: confident whitespace, one strong idea per spread, nothing decorative for decoration's sake.

Do not move to Step 2 until this is agreed.

---

## Step 2 — Map the Full Page Set

Before any image is generated, produce a page map and get it confirmed. A typical structure (adjust to the client):

```
Page 1 — Cover: logo, one-line positioning statement, restrained visual
Page 2 — Opening spread: who they are, in one confident paragraph
Page 3 — What they do (services/offering)
Page 4 — How they work (process, approach)
Page 5 — Proof: portfolio, case studies, or results
Page 6 — Team (if supplied)
Page 7 — Why them (differentiators, positioning against the obvious alternative)
Page 8 — Contact / closing: logo, WhatsApp/phone, website
```

This is a starting shape, not a formula — cut, merge, or reorder pages based on what the client actually needs said. A 4-page profile and a 12-page profile should feel equally deliberate, not padded or rushed.

---

## Step 3 — Design Language (what gives it taste)

This is the difference between "AI-generated corporate template" and "designed document." Apply these on every page:

### Layout
- **Asymmetry over centering.** Centered logo-and-text-block layouts are the single biggest tell of a generic template. Push elements off-center, let whitespace do work on one side.
- **One dominant element per page.** A huge number, a single striking image, one bold statement — not five equally-weighted boxes competing for attention.
- **Grid discipline, not grid rigidity.** Keep a consistent margin/column system across the document so pages feel related, but let content break the grid occasionally and deliberately (a full-bleed image, an oversized pull-quote) — perfect uniformity page after page reads as templated.
- **Generous whitespace is a design choice, not empty space.** If a page feels "unfinished," the instinct should be to sharpen the hierarchy, not to add a decorative icon or shape to fill it.

### Typography
- Oversized, confident headings — type is often the strongest visual element on a page, not an afterthought next to a stock photo.
- Real hierarchy: one heading weight, one body weight, one label/mono weight. No fourth font, no random italics for "style."
- Pull-quotes or single standout lines treated as graphic elements in their own right, not just bigger body text.

### Color
- Black/white/one accent, used with intent (a single accent-colored page, a single highlighted word, a single graphic shape) — not sprinkled evenly across every page out of habit.
- No gradients, no default "corporate blue," no decorative color blocks with no purpose.

### Imagery
- Real supplied photography treated with respect — full-bleed when it's strong, cropped tight and intentional rather than dropped into a generic rounded-corner box.
- If no photography is supplied and something visual is needed, prefer restrained abstract/graphic elements (a single shape, a typographic moment, a subtle texture) over generic stock-photo-style AI renders of "business people shaking hands" or "team high-fiving."
- Avoid: clip-art icons, generic 3D render clutter, obvious stock photography aesthetics, decorative shapes with no relationship to the content.

### What reads as "generic AI template" — avoid these
- Centered logo + centered heading + centered paragraph, repeated per page
- Icon grids where every service gets an identical generic icon
- Rounded rectangle "cards" for every content block
- Evenly spaced, evenly sized elements with no dominant focal point
- Stock gradient backgrounds or default corporate blue/gray palettes
- A different decorative shape "explaining" every page instead of the content doing the work

---

## Step 4 — Page-by-Page Generation

For each page:

1. **Rewrite the prompt from scratch** — do not reuse a generic template prompt across pages. Each page's prompt is derived fresh from that page's specific role in the page map, its actual content, and the locked design language above.
2. Generate as a high-fidelity A4 portrait image, print-ready.
3. Run it through QC (Step 5) before moving to the next page.
4. Keep the **system** locked across pages (margins, grid, font roles, color logic) even though each page's composition is bespoke.

### Page prompt template (adapt per page — never copy-paste verbatim)
```
A4 portrait, page [N] of [total] — [page's role, e.g. "Proof / Case Studies"].
Editorial magazine layout, asymmetric composition, one dominant focal
element: [describe it specifically for this page — a number, an image,
a statement].
Heading "[TEXT]" in [heading font], oversized, confident placement
[off-center/top/etc, not default-centered].
Body copy in [body font], short and restrained — [actual copy or brief].
Grid/margins matching document system: [describe locked grid].
Imagery: [exact supplied photo/asset, or "none — typographic page"].
Color: [locked palette], accent used only for [specific single purpose].
Logo: [exact supplied file, placement].
High-fidelity, print-ready, sharp typography, no artifacts, no broken
text, no placeholder or lorem ipsum content, no generic template feel.
```

---

## Step 5 — Quality Control (after every page)

- Does this page look designed, or does it look like a template with the logo swapped? If the latter — redo the composition, not just the copy.
- Text fully legible, correct fonts in correct roles
- Margins/grid consistent with rest of document
- Logo is the exact supplied file, undistorted, correctly placed
- No invented copy, no lorem ipsum, no fabricated stats or contact details
- Color matches the locked palette exactly, no drift page to page
- No AI artifacts — no malformed shapes, broken edges, garbled text, generic clip-art icons
- One clear focal point per page — nothing competing for attention
- Page reads clearly at a glance and fulfills its assigned role from the page map

If a page fails, regenerate that page only. Never restart the whole document over one failed page.

---

## Default Formula (unless the client's brand overrides it)

**A4 portrait • editorial minimalism • asymmetric layout • one dominant element per page • Cabinet Grotesk / Satoshi / JetBrains Mono • black + white + one restrained accent • exact supplied logo and photography • no generic template moves**
