---
name: tangison-flyer
description: Design, redesign, upgrade, and produce finished marketing flyers for Tangison and its clients. Use for promotional flyers, social media flyers, service flyers, event flyers, campaign graphics, digital posters, and similar single-page marketing visuals. Enforce a 4:5 aspect ratio by default, exact supplied logos, brand-accurate colours, conversion-focused copy, visual hierarchy, authentic imagery, and final-output precision. Use tangison-copywriting for the persuasion layer and this skill for the visual production layer.
---

# Tangison Flyer

A flyer is not a decorated document. It is a visual communication asset designed to make someone notice, understand, trust, and act within seconds.

Every Tangison flyer must combine:

**Strong copy + clear hierarchy + deliberate composition + authentic branding + visual precision.**

The flyer must look intentionally designed, not like an AI template.

---

# Step 1 — Context Intake

Before designing, check the available context and supplied assets.

Determine:

1. **Brand / issuing entity**
   - Tangison Technologies
   - Tangison Studio
   - Tangison Labs
   - Client brand

2. **Purpose**
   - Promotion
   - Service advertisement
   - Event
   - Announcement
   - Product
   - Campaign
   - Social media
   - General brand awareness

3. **Primary action**
   - Call
   - WhatsApp
   - Visit website
   - Book
   - Buy
   - Register
   - Follow
   - Enquire

4. **Audience**
   - Who is this for?
   - What do they need?
   - What should make them stop scrolling?

5. **Available assets**
   - Logo
   - Product photography
   - People
   - Brand assets
   - Existing flyer
   - Icons
   - Screenshots
   - Client-supplied imagery

Never invent important brand assets when authentic supplied assets exist.

---

# Step 2 — Default Format

## Default aspect ratio

**4:5**

This is the mandatory default for Tangison flyers unless the user explicitly specifies another format.

Use 4:5 for:

- Instagram posts
- Promotional flyers
- Social media graphics
- Service advertisements
- Digital campaigns
- General portrait flyers

Do not silently change the aspect ratio.

If the user explicitly requests:

- A4
- A3
- Square
- 16:9
- Story
- Landscape
- Print dimensions

follow the requested format instead.

## Default visual canvas

Use a clean portrait composition with enough breathing room for:

- Headline
- Supporting copy
- Main visual
- CTA/contact information
- Logo/brand mark

Never allow important information to sit dangerously close to the crop boundary.

---

# Step 3 — Brand Asset Integrity

## Logos

If the user supplies a logo:

**Use the exact supplied logo.**

Do not:

- redraw it
- recreate it
- reinterpret it
- replace it with an AI-generated logo
- change its proportions
- distort it
- add effects
- invent a new symbol
- substitute a generic logo

The supplied Tangison logo is the source of truth.

When multiple logo assets are supplied, use the explicitly selected/current master logo.

Maintain:

- original proportions
- correct spacing
- correct symbol
- correct wordmark
- correct orientation

The logo must remain recognisable at first glance.

---

# Step 4 — Tangison Studio Defaults

When the flyer is specifically for **Tangison Studio**, use the established Studio identity.

## Core palette

- Pure white: `#FFFFFF`
- Atlantic Black: `#111315`
- Terminal Black: `#0A0B0C`
- Signal Teal: `#2CB5B4`

Teal is an accent colour.

### Colour replacement rule

When adapting an existing design:

**Teal replaces unnecessary yellow, orange, purple, blue, red, gradient accents, or other decorative accent colours unless the user explicitly asks to preserve another colour.**

For example:

Original yellow circle → **Signal Teal**

Original yellow screen → **Signal Teal**

Original yellow rays → **Signal Teal**

Original orange highlight → **Signal Teal**

Do not leave random competing accent colours behind.

The result should feel like one coherent Tangison Studio system.

### White

White means:

**Pure white `#FFFFFF`**

Do not introduce:

- cream
- ivory
- dirty white
- grey-white
- beige

unless explicitly requested.

---

# Step 5 — Copywriting Layer

The copy must align with `tangison-copywriting`.

Do not write generic flyer copy.

Use:

- clarity
- specificity
- concise messaging
- strong benefit orientation
- natural language
- confident tone
- one clear CTA

Use the appropriate framework when useful:

| Flyer | Preferred framework |
|---|---|
| General promotion | AIDA |
| Pain/problem-led offer | PAS |
| Transformation | BAB |
| Product/service features | FAB |
| Short headline | 4 U's |

The visual flyer normally contains:

### 1. Hook

The largest message.

### 2. Supporting statement

Explain or reinforce the hook.

### 3. Offer / benefit

Tell the viewer what they actually get.

### 4. CTA

Tell them what to do next.

### 5. Contact / URL

Make the next step immediately accessible.

Never overload a flyer with paragraphs.

---

# Step 6 — Headline Rules

The headline must be:

- immediately readable
- visually dominant
- short where possible
- benefit-led
- relevant to the audience
- consistent with the actual offer

Avoid:

- generic motivational language
- empty buzzwords
- corporate clichés
- exaggerated claims
- fake urgency
- invented statistics
- fake testimonials

Examples:

Weak:

> We provide innovative solutions for your business.

Strong:

> We make things make sense.

Weak:

> Take your business to the next level.

Strong:

> Your brand should work as hard as you do.

---

# Step 7 — Visual Hierarchy

Every flyer should have a clear hierarchy.

Recommended order:

**1. Headline**

↓

**2. Main visual**

↓

**3. Supporting message**

↓

**4. CTA**

↓

**5. Contact / website**

↓

**6. Logo**

The viewer should understand the flyer in approximately three seconds.

Do not make every element equally large.

One thing must dominate.

---

# Step 8 — Main Visual

The visual should support the message.

Use:

- authentic photography
- supplied photography
- carefully selected visual assets
- realistic product imagery
- controlled graphic compositions
- simple geometric forms

Avoid:

- generic stock-looking people
- distorted hands
- fake logos
- strange objects
- excessive 3D effects
- random decorative elements
- obvious AI artefacts
- unnecessary gradients
- template-style clutter

If the user supplies a visual reference, preserve its core concept while applying the requested Tangison treatment.

---

# Step 9 — Existing Flyer Redesign

When upgrading an existing flyer:

Do not automatically redesign everything.

First identify:

- what already works
- the core message
- the visual concept
- the hierarchy
- the brand elements
- the main object

Then make the requested changes precisely.

For example:

If the user says:

> Change the number to 0853411522.

Change only the number.

If they say:

> Change the yellow to teal.

Replace the yellow consistently throughout the design.

If they say:

> Use the attached Tangison logo.

Use that exact logo.

If they say:

> Add studio.tangison.com.

Add the URL without inventing additional contact information.

---

# Step 10 — Tangison Studio Contact Defaults

When the flyer is for Tangison Studio and no alternative contact details are supplied:

**Phone**

`085 341 1522`

**Website**

`studio.tangison.com`

Use these exact values.

Do not accidentally use:

- old phone numbers
- placeholder numbers
- fabricated URLs
- incorrect domains

---

# Step 11 — Composition

Prefer:

- asymmetric layouts
- strong alignment
- generous whitespace
- oversized typography
- controlled negative space
- large hero imagery
- intentional cropping
- clear margins

Avoid:

- everything centred by default
- excessive boxes
- excessive cards
- decorative borders everywhere
- random floating icons
- excessive shadows
- crowded bottom sections
- tiny unreadable text

The design should feel like a professional creative studio produced it.

---

# Step 12 — Typography

Typography must create hierarchy rather than decoration.

Recommended Tangison Studio direction:

### Headings
Cabinet Grotesk

### Body
Satoshi

### Metadata / URLs / technical details
JetBrains Mono

Prioritise:

- large headlines
- strong weight contrast
- clean line spacing
- controlled tracking
- short text blocks

Do not use excessive font styles.

Maximum principle:

**Few styles, strong hierarchy.**

---

# Step 13 — Colour Discipline

A Tangison flyer should normally use:

**Black + White + Teal**

Teal should be intentional.

Good uses:

- hero background shape
- screen colour
- highlight
- CTA accent
- graphic rays
- small labels
- key visual element

Bad uses:

- huge blocks of unnecessary teal
- long paragraphs in teal
- every element teal
- competing accent colours
- rainbow palettes
- random gradients

If adapting a colourful reference:

**Remove unnecessary colours and translate the visual language into Tangison's palette.**

---

# Step 14 — CTA

The CTA must be obvious.

Prefer:

**WhatsApp 085 341 1522**

or

**studio.tangison.com**

or a specific action such as:

**Book a Consultation**

**Start Your Project**

**Talk to Tangison**

Avoid generic:

- Click here
- Submit
- Learn more

unless context requires them.

---

# Step 15 — Contact Placement

Contact information should be easy to find without competing with the headline.

A common footer structure:

`WhatsApp 085 341 1522     studio.tangison.com     [Tangison Logo]`

Keep spacing clean.

Never make contact information microscopic.

---

# Step 16 — Logo Placement

The logo should have breathing room.

Do not:

- squeeze it against the edge
- place it over busy imagery
- distort it
- make it unnecessarily huge
- compete with the headline

The logo should identify the brand, not become the entire advertisement.

---

# Step 17 — Image Generation / Editing Rules

When generating or editing visual artwork:

1. Preserve the requested composition.
2. Preserve the supplied logo exactly.
3. Use 4:5 by default.
4. Apply pure white `#FFFFFF` where white is required.
5. Replace non-brand accent colours with Tangison teal where requested.
6. Keep black elements genuinely black.
7. Avoid invented text where precise typography is required.
8. Avoid fabricated contact details.
9. Keep visual objects anatomically and physically coherent.
10. Do not introduce unrelated decorative elements.
11. Maintain the core idea of the reference.
12. Prioritise precision over visual complexity.

When editing a supplied flyer, the goal is:

**same concept, better execution.**

Not:

**completely different design.**

unless the user explicitly requests a complete redesign.

---

# Step 18 — Social Media Readability

Because many Tangison flyers are viewed on phones:

Check the design at small size.

The viewer should still be able to identify:

- brand
- headline
- offer
- CTA

without zooming.

Do not sacrifice readability for visual detail.

---

# Step 19 — Precision QC

Before delivery, inspect the entire flyer.

### Content QC

- Correct phone number
- Correct URL
- Correct spelling
- Correct punctuation
- Correct brand name
- No placeholders
- No invented claims
- No duplicate text
- No missing CTA

### Brand QC

- Exact supplied logo
- Correct colours
- Pure white where required
- Teal replacing unwanted accent colours
- No accidental competing palette

### Layout QC

- 4:5 unless otherwise specified
- Safe margins
- No clipped text
- No overlapping elements
- No awkward spacing
- Strong hierarchy
- CTA visible
- Logo visible
- Contact details readable

### Visual QC

- No distorted objects
- No malformed hands
- No strange shadows
- No accidental artefacts
- No fake-looking brand marks
- No unnecessary decorative clutter

---

# Step 20 — Final Quality Standard

A Tangison flyer should pass this test:

### At 3 seconds:

Can I tell what this is about?

### At 5 seconds:

Do I understand the value?

### At 10 seconds:

Do I know what to do next?

If the answer to any of these is no, redesign the hierarchy.

---

# Default Tangison Flyer Formula

Unless the user specifies otherwise:

**4:5 portrait**

**Pure white background**

**Black typography**

**Signal Teal `#2CB5B4` accent**

**Exact supplied Tangison logo**

**Large visual**

**Short persuasive headline**

**Concise supporting copy**

**One clear CTA**

**085 341 1522**

**studio.tangison.com**

**No unnecessary colours**

**No em dashes**

**No generic AI copy**

**No fabricated proof**

**No AI-template aesthetic**

---

# Relationship With Tangison Copywriting

`tangison-copywriting` controls:

- message
- persuasion
- headlines
- benefits
- CTA
- audience
- framework
- voice

`tangison-flyer` controls:

- composition
- hierarchy
- visual direction
- colour
- logo integrity
- aspect ratio
- imagery
- layout
- production QC

Together:

**Copy makes the viewer care.  
Design makes the viewer notice.  
The CTA makes the viewer act.**

---

# Final Rule

Do not ask unnecessary questions when the supplied reference and instructions already provide enough information.

If the user says:

> Make this flyer Tangison.

Apply the Tangison defaults.

If the user says:

> Change the yellow to teal, use the attached logo, change the number and add the website.

Execute those changes precisely.

If no aspect ratio is specified:

**4:5 is mandatory by default.**

Only use another ratio when the user explicitly requests it.
