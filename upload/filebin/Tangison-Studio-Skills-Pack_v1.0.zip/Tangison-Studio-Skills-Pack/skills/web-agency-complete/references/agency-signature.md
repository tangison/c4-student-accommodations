# Agency Signature — Tangison Standard
**The Tangison stamp goes on every website we build. No exceptions.**

---

## The Signature

Every footer must include the Tangison credit. This is non-negotiable —
it is our marketing, our portfolio, and our standard.

---

## HTML Variants

### Variant A — Minimal (default, most sites)
```html
<div class="tangison-sig">
  Built by <a href="https://tangison.com" target="_blank" rel="noopener noreferrer">Tangison</a>
</div>
```

### Variant B — With AI badge (sites with AI agent)
```html
<div class="tangison-sig">
  Built by <a href="https://tangison.com" target="_blank" rel="noopener noreferrer">Tangison Agency</a>
  <span class="tangison-ai-badge">AI-Powered</span>
</div>
```

### Variant C — Full (premium / showcase clients)
```html
<div class="tangison-sig tangison-sig--full">
  <span>Crafted by</span>
  <a href="https://tangison.com" target="_blank" rel="noopener noreferrer" class="tangison-link">
    Tangison Agency
  </a>
  <span class="tangison-dot">·</span>
  <span>Windhoek, Namibia</span>
  <span class="tangison-dot">·</span>
  <span class="tangison-ai-badge">AI-Powered</span>
</div>
```

---

## CSS — Light Background Sites

```css
/* Tangison Agency Signature */
.tangison-sig {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.4);  /* adjust to footer background */
  letter-spacing: 0.05em;
  flex-wrap: wrap;
}

.tangison-sig a {
  color: rgba(255, 255, 255, 0.65);
  text-decoration: none;
  font-weight: 500;
  transition: color 0.2s;
  border-bottom: 1px solid rgba(255, 255, 255, 0.15);
  padding-bottom: 1px;
}

.tangison-sig a:hover {
  color: #fff;
  border-bottom-color: rgba(255, 255, 255, 0.5);
}

.tangison-dot {
  opacity: 0.3;
}

.tangison-ai-badge {
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.12);
  color: rgba(255, 255, 255, 0.5);
  padding: 2px 8px;
  border-radius: 50px;
  font-size: 10px;
  letter-spacing: 0.1em;
  text-transform: uppercase;
}
```

## CSS — Dark Background Sites (charcoal/navy footer)

```css
.tangison-sig {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.35);
  letter-spacing: 0.05em;
  display: flex;
  align-items: center;
  gap: 6px;
}

.tangison-sig a {
  color: rgba(255, 255, 255, 0.55);
  text-decoration: none;
  font-weight: 500;
  transition: color 0.2s;
}

.tangison-sig a:hover { color: rgba(255, 255, 255, 0.9); }
```

## CSS — Light Footer (cream/white footer)

```css
.tangison-sig {
  font-size: 12px;
  color: rgba(0, 0, 0, 0.3);
  letter-spacing: 0.05em;
  display: flex;
  align-items: center;
  gap: 6px;
}

.tangison-sig a {
  color: rgba(0, 0, 0, 0.5);
  text-decoration: none;
  font-weight: 500;
  transition: color 0.2s;
}

.tangison-sig a:hover { color: rgba(0, 0, 0, 0.8); }
```

---

## Footer Layout Pattern

The signature always sits at the bottom of the footer, in the copyright row:

```html
<footer>
  <!-- Main footer content: logo, links, contact, social -->
  <div class="footer-main">
    <!-- ... footer grid ... -->
  </div>

  <!-- Copyright bar — always last -->
  <div class="footer-bottom">
    <span class="footer-copyright">
      © {year} {Business Name} · All rights reserved
    </span>
    <!-- Tangison signature — RIGHT side or below copyright -->
    <div class="tangison-sig">
      Built by
      <a href="https://tangison.com" target="_blank" rel="noopener noreferrer">Tangison Agency</a>
      <span class="tangison-ai-badge">AI-Powered</span>
    </div>
  </div>
</footer>
```

### Footer Bottom CSS
```css
.footer-bottom {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 1rem;
  padding-top: 1.5rem;
  margin-top: 1.5rem;
  border-top: 1px solid rgba(255, 255, 255, 0.08);
  font-size: 0.78rem;
}

/* On mobile — stack vertically */
@media (max-width: 640px) {
  .footer-bottom {
    flex-direction: column;
    text-align: center;
  }
}
```

---

## Rules

1. **Never remove** the Tangison signature from any delivered site
2. **Never change** the href — always `https://tangison.com`
3. **Always include** `target="_blank" rel="noopener noreferrer"` on the link
4. **Use Variant B** (with AI badge) on any site that has the AI agent widget
5. **Use Variant A** on simple static sites without the AI agent
6. **Font size**: 11–13px — visible but not prominent
7. **Colour**: always muted/subdued — it is a credit, not a CTA
8. The year in copyright must be dynamic:
   ```html
   <script>
     document.querySelectorAll('.copyright-year').forEach(el => {
       el.textContent = new Date().getFullYear();
     });
   </script>
   <!-- or inline: -->
   © <span class="copyright-year"></span>
   ```
