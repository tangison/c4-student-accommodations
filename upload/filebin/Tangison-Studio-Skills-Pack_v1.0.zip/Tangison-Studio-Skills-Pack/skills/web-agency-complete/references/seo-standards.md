# SEO Standards — Tangison Agency
**Every page ships with all of these. No exceptions.**

---

## 1. Required Meta Tags (Every Page)

```html
<head>
  <!-- Core -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <!-- Title: 50–60 characters max -->
  <title>{Page Name} | {Business Name}</title>

  <!-- Description: 120–155 characters max, includes primary keyword -->
  <meta name="description" content="{description}">

  <!-- Robots: index/noindex, follow/nofollow -->
  <meta name="robots" content="index, follow">
  <!-- On error/utility pages: -->
  <!-- <meta name="robots" content="noindex, nofollow"> -->

  <!-- Canonical: prevents duplicate content issues -->
  <link rel="canonical" href="https://{domain}/{page-path}">

  <!-- Language -->
  <meta name="language" content="English">

  <!-- Author -->
  <meta name="author" content="{Business Name}">

  <!-- Theme -->
  <meta name="theme-color" content="{primary_color}">
</head>
```

---

## 2. Open Graph Tags (Every Page)

```html
<!-- Open Graph — controls how page looks when shared on Facebook, WhatsApp, LinkedIn -->
<meta property="og:type" content="website">
<meta property="og:site_name" content="{Business Name}">
<meta property="og:title" content="{Page Title}">
<meta property="og:description" content="{description — can be same as meta description}">
<meta property="og:url" content="https://{domain}/{page-path}">
<meta property="og:image" content="https://{domain}/og-image.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="{Business Name} — {tagline}">
<meta property="og:locale" content="en_US">
```

---

## 3. Twitter Card Tags (Every Page)

```html
<!-- Twitter / X Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{Page Title}">
<meta name="twitter:description" content="{description}">
<meta name="twitter:image" content="https://{domain}/og-image.jpg">
<meta name="twitter:image:alt" content="{Business Name} — {tagline}">
<!-- If business has Twitter: -->
<!-- <meta name="twitter:site" content="@{handle}"> -->
```

---

## 4. Favicon Tags (Every Page)

```html
<!-- Favicon set — supports all browsers and devices -->
<link rel="icon" type="image/svg+xml" href="/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="manifest" href="/manifest.json">
```

---

## 5. Schema.org JSON-LD (Varies by Page)

### Home Page — LocalBusiness
```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "{Business Name}",
  "url": "https://{domain}",
  "logo": "https://{domain}/logo.svg",
  "description": "{Business description}",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "{street}",
    "addressLocality": "{city}",
    "addressCountry": "{country code e.g. NA}"
  },
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "{phone}",
    "contactType": "customer service",
    "availableLanguage": "English"
  },
  "sameAs": [
    "{Facebook URL}",
    "{Instagram URL}",
    "{WhatsApp URL}"
  ]
}
</script>
```

### Product Page — Product
```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "{Product Name}",
  "description": "{Product description}",
  "brand": {
    "@type": "Brand",
    "name": "{Business Name}"
  },
  "image": "https://{domain}/images/{product-image}.jpg"
}
</script>
```

### FAQ Page — FAQPage
```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "{Question text}",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "{Answer text}"
      }
    }
  ]
}
</script>
```

### Article / Blog Post — Article
```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "{Article title}",
  "author": {
    "@type": "Person",
    "name": "{Author name}"
  },
  "publisher": {
    "@type": "Organization",
    "name": "{Business Name}",
    "logo": {
      "@type": "ImageObject",
      "url": "https://{domain}/logo.svg"
    }
  },
  "datePublished": "{YYYY-MM-DD}",
  "dateModified": "{YYYY-MM-DD}",
  "image": "https://{domain}/images/{article-image}.jpg"
}
</script>
```

---

## 6. Performance SEO Rules

### Font Loading (never block render)
```html
<!-- Preconnect first -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<!-- Then load async -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=...&display=swap">
```

### Image Rules
```html
<!-- Always: width, height, alt, loading -->
<img
  src="/images/hero.jpg"
  alt="{descriptive alt text — never empty on content images}"
  width="1200"
  height="600"
  loading="lazy"
  decoding="async"
>
<!-- Hero image: loading="eager" (above the fold) -->
<!-- All other images: loading="lazy" -->
```

### Critical CSS
- Inline critical above-fold CSS in `<style>` in `<head>`
- Load non-critical CSS at bottom of `<body>` or with `media="print" onload="this.media='all'"`
- Never use `@import` in CSS (blocks render)

---

## 7. URL Structure Rules

| Rule | Good | Bad |
|------|------|-----|
| Lowercase only | `/about-us` | `/About-Us` |
| Hyphens not underscores | `/our-services` | `/our_services` |
| No trailing slash (except home) | `/contact` | `/contact/` |
| Descriptive, not generic | `/kalahari-melon-oil` | `/product?id=12` |
| Short — under 60 chars | `/privacy-policy` | `/legal-pages/privacy-policy-updated-2024` |

---

## 8. Core Web Vitals Checklist

Apply to every project:

- [ ] **LCP (Largest Contentful Paint)** < 2.5s — preload hero image, avoid render-blocking resources
- [ ] **CLS (Cumulative Layout Shift)** < 0.1 — always set width/height on images, avoid inserting content above existing
- [ ] **INP (Interaction to Next Paint)** < 200ms — avoid heavy JS on main thread, use event delegation
- [ ] **FCP (First Contentful Paint)** < 1.8s — inline critical CSS, defer non-critical JS

### Preload Hero Image
```html
<link rel="preload" as="image" href="/images/hero.webp" fetchpriority="high">
```

---

## 9. Accessibility (affects SEO)

```html
<!-- Language must be set -->
<html lang="en">

<!-- Skip link — first element in body -->
<a href="#main-content" class="skip-link">Skip to main content</a>

<!-- Landmark roles -->
<header role="banner">
<nav role="navigation" aria-label="Main navigation">
<main id="main-content" role="main">
<footer role="contentinfo">

<!-- All interactive elements need visible focus states -->
/* In CSS: never remove outline without replacing it */
:focus-visible { outline: 2px solid {primary_color}; outline-offset: 2px; }
```

---

## 10. SEO Copywriting Rules

Apply to all auto-generated page content:

- **Title tags**: Primary keyword near the front — `Kalahari Melon Seed Oil | Tuliikeni Oil Solutions`
- **H1**: One per page. Matches or closely reflects title tag. Contains primary keyword.
- **H2–H6**: Logical hierarchy. Never skip levels (H1 → H3 without H2).
- **Body copy**: Minimum 300 words on core pages. FAQ and legal pages can be shorter.
- **Internal links**: Every page links to at least 2 other pages. Never orphan a page.
- **Alt text**: Describes the image for a blind user. Never keyword-stuff.
- **No keyword stuffing**: Natural language. Write for humans first.
