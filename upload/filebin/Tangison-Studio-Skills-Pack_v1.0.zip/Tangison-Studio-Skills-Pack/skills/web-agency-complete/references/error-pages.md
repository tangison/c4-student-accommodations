# Error Pages — Tangison Standard
**Full on-brand HTML templates for all error states.**

---

## Rules (repeat from page-inventory.md)
- All styled on-brand — no browser defaults ever
- All include: logo, code, headline, explanation, home CTA
- All have `<meta name="robots" content="noindex, nofollow">`
- 404 includes popular pages or search
- 503 includes a "back soon" message
- Adapt colours using `var(--primary)` and `var(--cream)` from site CSS

---

## 404 — Not Found (Full Template)

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex, nofollow">
  <title>404 — Page Not Found | {Business Name}</title>
  <link rel="icon" href="/favicon.svg">
  <style>
    :root {
      --primary: {primary_color};
      --cream: {background_color};
      --text: {text_color};
    }
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: {body_font}, sans-serif;
      background: var(--cream);
      color: var(--text);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 2rem;
      text-align: center;
    }
    .error-code {
      font-family: {display_font}, serif;
      font-size: clamp(6rem, 20vw, 12rem);
      font-weight: 300;
      color: var(--primary);
      opacity: 0.12;
      line-height: 1;
      margin-bottom: -2rem;
    }
    .error-icon { font-size: 3rem; margin-bottom: 1rem; }
    h1 {
      font-family: {display_font}, serif;
      font-size: clamp(1.5rem, 4vw, 2.5rem);
      font-weight: 400;
      color: var(--primary);
      margin-bottom: 1rem;
    }
    p {
      max-width: 420px;
      color: #7A7468;
      line-height: 1.7;
      margin-bottom: 2.5rem;
      font-size: 1rem;
    }
    .btn {
      display: inline-block;
      background: var(--primary);
      color: #fff;
      padding: 0.9rem 2rem;
      border-radius: 2px;
      text-decoration: none;
      font-size: 0.85rem;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      transition: opacity 0.2s;
    }
    .btn:hover { opacity: 0.85; }
    .popular-links {
      margin-top: 3rem;
      display: flex;
      gap: 1rem;
      flex-wrap: wrap;
      justify-content: center;
    }
    .popular-link {
      color: var(--primary);
      text-decoration: none;
      font-size: 0.85rem;
      border-bottom: 1px solid rgba(0,0,0,0.2);
      padding-bottom: 2px;
    }
    .popular-link:hover { border-bottom-color: var(--primary); }
    .logo-wrap { position: absolute; top: 24px; left: 24px; }
    .logo-wrap img { height: 36px; }
  </style>
</head>
<body>
  <a href="/" class="logo-wrap" aria-label="{Business Name} home">
    <img src="/logo.svg" alt="{Business Name}">
  </a>

  <div class="error-code">404</div>
  <div class="error-icon">🌿</div>
  <h1>Page not found</h1>
  <p>
    The page you're looking for doesn't exist or may have been moved.
    Let's get you back on track.
  </p>
  <a href="/" class="btn">Back to Home</a>

  <div class="popular-links">
    <a href="/" class="popular-link">Home</a>
    <a href="/about" class="popular-link">About</a>
    <a href="/services" class="popular-link">Services</a>
    <a href="/contact" class="popular-link">Contact</a>
  </div>
</body>
</html>
```

---

## 500 — Server Error

```html
<!-- Same structure as 404 — change these values: -->
<title>500 — Something Went Wrong | {Business Name}</title>

<div class="error-code">500</div>
<div class="error-icon">⚙️</div>
<h1>Something went wrong</h1>
<p>
  We're experiencing a technical issue on our end. Our team has been notified.
  Please try again in a few minutes.
</p>
<a href="/" class="btn">Back to Home</a>
<!-- No popular links needed on 500 -->
```

---

## 503 — Service Unavailable / Maintenance

```html
<title>We'll Be Right Back | {Business Name}</title>

<div class="error-code" style="font-size: clamp(3rem, 10vw, 7rem); opacity: 0.1;">503</div>
<div class="error-icon">🔧</div>
<h1>We'll be right back</h1>
<p>
  We're doing some quick maintenance to improve your experience.
  We'll be back shortly — thank you for your patience.
</p>
<!-- Optional: countdown or estimate -->
<p style="font-size: 0.85rem; color: #9ca3af;">
  Expected back: <strong>{time estimate}</strong>
</p>
<a href="mailto:{email}" class="btn">Contact Us</a>
```

---

## 403 — Forbidden

```html
<title>Access Denied | {Business Name}</title>

<div class="error-code">403</div>
<div class="error-icon">🔒</div>
<h1>Access denied</h1>
<p>
  You don't have permission to view this page.
  If you think this is a mistake, please get in touch.
</p>
<a href="/" class="btn">Back to Home</a>
```

---

## Maintenance Mode (Full Screen)

Use when the whole site is down for planned maintenance:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex, nofollow">
  <title>Maintenance | {Business Name}</title>
  <style>
    body {
      margin: 0;
      min-height: 100vh;
      background: {primary_color};
      color: #fff;
      font-family: {body_font}, sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      padding: 2rem;
    }
    .logo { font-family: {display_font}, serif; font-size: 2rem; letter-spacing: 0.15em; margin-bottom: 2rem; opacity: 0.9; }
    h1 { font-family: {display_font}, serif; font-size: clamp(2rem, 5vw, 3.5rem); font-weight: 300; margin-bottom: 1rem; }
    p { max-width: 400px; opacity: 0.7; line-height: 1.7; margin-bottom: 2rem; }
    .contact-link { color: #fff; opacity: 0.6; text-decoration: none; border-bottom: 1px solid rgba(255,255,255,0.3); }
    .contact-link:hover { opacity: 1; }
  </style>
</head>
<body>
  <div class="logo">{Business Name}</div>
  <h1>Under Maintenance</h1>
  <p>
    We're making improvements to serve you better.
    We'll be back very soon.
  </p>
  <p>
    Questions? <a href="mailto:{email}" class="contact-link">{email}</a>
  </p>
</body>
</html>
```
