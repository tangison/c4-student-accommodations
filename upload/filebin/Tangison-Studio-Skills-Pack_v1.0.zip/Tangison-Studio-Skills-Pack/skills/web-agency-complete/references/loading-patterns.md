# Loading Patterns — Tangison Standard
**Every Tangison site ships with polished loading states. Never show a blank screen.**

---

## 1. Page Loading Screen (Initial Load)

A full-screen branded loader that shows while JS/assets initialise.
Remove it once the page is ready with a fade-out.

```html
<!-- Add immediately after <body> tag -->
<div id="site-loader" aria-hidden="true">
  <div class="loader-inner">
    <div class="loader-logo">
      <!-- Use SVG logo or just the icon mark -->
      <img src="/logo.svg" alt="{Business Name}" width="60" height="60">
    </div>
    <div class="loader-bar">
      <div class="loader-fill"></div>
    </div>
  </div>
</div>
```

```css
/* Site loader */
#site-loader {
  position: fixed;
  inset: 0;
  z-index: 99999;
  background: var(--cream, #F9F5EE);
  display: flex;
  align-items: center;
  justify-content: center;
  transition: opacity 0.5s ease, visibility 0.5s ease;
}

#site-loader.hidden {
  opacity: 0;
  visibility: hidden;
  pointer-events: none;
}

.loader-inner {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 24px;
}

.loader-logo {
  animation: loaderPulse 1.5s ease-in-out infinite;
}

@keyframes loaderPulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.6; transform: scale(0.95); }
}

.loader-bar {
  width: 120px;
  height: 2px;
  background: rgba(0, 0, 0, 0.08);
  border-radius: 2px;
  overflow: hidden;
}

.loader-fill {
  height: 100%;
  background: var(--primary, #2C4A1E);
  border-radius: 2px;
  animation: loaderProgress 1.5s ease-in-out infinite;
}

@keyframes loaderProgress {
  0% { width: 0%; transform: translateX(0); }
  50% { width: 80%; }
  100% { width: 100%; transform: translateX(0); }
}
```

```javascript
// Remove loader when page is ready
window.addEventListener('load', function() {
  const loader = document.getElementById('site-loader');
  if (loader) {
    loader.classList.add('hidden');
    // Remove from DOM after transition
    setTimeout(() => loader.remove(), 600);
  }
});
```

---

## 2. Skeleton Screens (Content Loading)

Use when fetching data asynchronously (products, blog posts, etc.).

```html
<!-- Skeleton card — product or blog post -->
<div class="skeleton-card" aria-hidden="true">
  <div class="skeleton skeleton-image"></div>
  <div class="skeleton-body">
    <div class="skeleton skeleton-title"></div>
    <div class="skeleton skeleton-text"></div>
    <div class="skeleton skeleton-text skeleton-text--short"></div>
  </div>
</div>
```

```css
/* Skeleton shimmer animation */
.skeleton {
  background: linear-gradient(
    90deg,
    rgba(0, 0, 0, 0.06) 25%,
    rgba(0, 0, 0, 0.10) 37%,
    rgba(0, 0, 0, 0.06) 63%
  );
  background-size: 400% 100%;
  animation: skeletonShimmer 1.4s ease infinite;
  border-radius: 4px;
}

@keyframes skeletonShimmer {
  0% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

.skeleton-card {
  border-radius: 4px;
  overflow: hidden;
  border: 1px solid rgba(0,0,0,0.06);
}

.skeleton-image {
  width: 100%;
  aspect-ratio: 4/3;
}

.skeleton-body {
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.skeleton-title {
  height: 24px;
  width: 70%;
}

.skeleton-text {
  height: 14px;
  width: 100%;
}

.skeleton-text--short {
  width: 55%;
}

/* Dark theme skeleton */
.dark .skeleton {
  background: linear-gradient(
    90deg,
    rgba(255, 255, 255, 0.04) 25%,
    rgba(255, 255, 255, 0.08) 37%,
    rgba(255, 255, 255, 0.04) 63%
  );
  background-size: 400% 100%;
}
```

---

## 3. Button Loading State

```html
<button class="btn-primary" id="submitBtn">
  <span class="btn-label">Send Message</span>
  <span class="btn-spinner" aria-hidden="true"></span>
</button>
```

```css
.btn-spinner {
  display: none;
  width: 16px;
  height: 16px;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
}

.btn-primary.loading .btn-label { opacity: 0.6; }
.btn-primary.loading .btn-spinner { display: inline-block; }
.btn-primary.loading { pointer-events: none; opacity: 0.85; }

@keyframes spin {
  to { transform: rotate(360deg); }
}
```

```javascript
// Usage
function setLoading(btn, isLoading) {
  btn.classList.toggle('loading', isLoading);
  btn.disabled = isLoading;
}

// On form submit:
const btn = document.getElementById('submitBtn');
setLoading(btn, true);
// ... do async work ...
setLoading(btn, false);
```

---

## 4. Image Lazy Load with Blur-Up

Gives a smooth "blur to sharp" effect on lazy images:

```html
<div class="img-wrap">
  <!-- Tiny blurred placeholder (base64 or tiny version) -->
  <img
    class="img-placeholder"
    src="data:image/jpeg;base64,{tiny_blurred_base64}"
    alt=""
    aria-hidden="true"
  >
  <!-- Real image loads lazily -->
  <img
    class="img-main"
    src="/images/product.jpg"
    alt="{descriptive alt}"
    loading="lazy"
    decoding="async"
    onload="this.classList.add('loaded')"
  >
</div>
```

```css
.img-wrap {
  position: relative;
  overflow: hidden;
  background: var(--cream-deep, #EAE0CE);
}

.img-placeholder {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  filter: blur(20px);
  transform: scale(1.05); /* prevents blur edges */
}

.img-main {
  position: relative;
  width: 100%;
  height: 100%;
  object-fit: cover;
  opacity: 0;
  transition: opacity 0.4s ease;
}

.img-main.loaded {
  opacity: 1;
}
```

---

## 5. Navigation Transition (Page-to-Page)

For multi-page sites (not SPAs), a quick page transition feel:

```javascript
// Add to every page
document.addEventListener('DOMContentLoaded', function() {
  // Fade in on load
  document.body.style.opacity = '0';
  document.body.style.transition = 'opacity 0.3s ease';
  requestAnimationFrame(() => {
    document.body.style.opacity = '1';
  });

  // Fade out on navigate
  document.querySelectorAll('a[href]').forEach(link => {
    const href = link.getAttribute('href');
    // Only internal links, not anchors, not external
    if (href && !href.startsWith('#') && !href.startsWith('http') && !href.startsWith('mailto') && !href.startsWith('tel')) {
      link.addEventListener('click', function(e) {
        e.preventDefault();
        document.body.style.opacity = '0';
        setTimeout(() => { window.location.href = href; }, 280);
      });
    }
  });
});
```
