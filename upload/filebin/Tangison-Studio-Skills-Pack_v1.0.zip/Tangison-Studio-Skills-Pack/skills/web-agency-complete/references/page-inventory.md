# Page Inventory — Complete Website Page List
**Tangison Agency Standard — All pages required by default**

Every website built with the web-agency-complete skill ships with every page
in this list. Pages not in the client brief are generated as minimal, styled,
on-brand stubs. No exceptions.

---

## Table of Contents
1. Core Pages
2. Legal & Compliance Pages
3. Error Pages
4. UX Utility Pages
5. SEO & Technical Files
6. Auth Pages (conditional)
7. E-commerce Pages (conditional)
8. Blog / Content Pages (conditional)

---

## 1. Core Pages
*Always generated. Full content.*

| Page | File | Priority | Notes |
|------|------|----------|-------|
| Home | `index.html` | P0 | Hero, value prop, CTA, testimonials |
| About | `about.html` | P0 | Story, team, mission, values |
| Services / Products | `services.html` or `products.html` | P0 | Full offering grid |
| Contact | `contact.html` | P0 | Form, map, social, WhatsApp CTA |
| FAQ | `faq.html` | P1 | At minimum 8 questions, accordion layout |

---

## 2. Legal & Compliance Pages
*Always generated. Use standard templates from `references/legal-pages.md`.*
*Pre-fill business name, email, location. Mark dates clearly.*

| Page | File | Priority | Notes |
|------|------|----------|-------|
| Privacy Policy | `privacy.html` | P0 | GDPR/POPIA compliant. Required by law. |
| Terms & Conditions | `terms.html` | P0 | Standard T&Cs, customised per business |
| Cookie Policy | `cookies.html` | P1 | Required if using analytics or cookies |
| Disclaimer | `disclaimer.html` | P1 | Limits liability on advice/content |
| Accessibility Statement | `accessibility.html` | P2 | WCAG 2.1 AA commitment |

### Legal Page Rules
- Always include `Last updated: {date}` at the top
- Always include the business legal name and email
- Never leave placeholder text — fill with real standard copy
- Link Privacy Policy and Terms in every footer
- Cookie banner must reference Cookie Policy page

---

## 3. Error Pages
*Always generated. Styled on-brand. Never show default browser errors.*

| Page | HTTP Code | File | What it should do |
|------|-----------|------|-------------------|
| Not Found | 404 | `404.html` | Friendly message + nav back to home + search if available |
| Forbidden | 403 | `403.html` | Explain access denied + link to contact |
| Server Error | 500 | `500.html` | Apologise + link home + optional support email |
| Service Unavailable | 503 | `503.html` | Maintenance message + estimated return time |
| Bad Request | 400 | `400.html` | Explain bad request simply + link home |
| Maintenance | `maintenance.html` | — | Full-screen maintenance mode page |

### Error Page Rules
- All error pages must include: logo, headline, short explanation, CTA button back to home
- Style must match main site — no default browser styling
- 404 must include a search box or "popular pages" list
- 503 must include an optional countdown or "back soon" message
- Error pages must NOT be indexed: `<meta name="robots" content="noindex, nofollow">`

### Error Page HTML Pattern
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex, nofollow">
  <title>404 — Page Not Found | {Business Name}</title>
  <link rel="stylesheet" href="/css/main.css">
</head>
<body class="error-page">
  <nav><!-- same nav as main site --></nav>
  <main class="error-main">
    <div class="error-code">404</div>
    <h1>Page not found</h1>
    <p>The page you're looking for doesn't exist or has been moved.</p>
    <a href="/" class="btn-primary">Back to Home</a>
  </main>
  <footer><!-- same footer as main site --></footer>
</body>
</html>
```

---

## 4. UX Utility Pages
*Generated as minimal, styled stubs.*

| Page | File | When it shows |
|------|------|--------------|
| Thank You | `thank-you.html` | After contact form submission |
| Unsubscribe | `unsubscribe.html` | Email unsubscribe landing |
| Link Expired | `link-expired.html` | For magic links or time-limited URLs |
| Coming Soon | `coming-soon.html` | For pre-launch or unreleased sections |
| Search Results | `search.html` | If site has search functionality |
| Empty State | — | Component, not page — no results found |

### Thank You Page Rules
- Always confirm what happened: "Your message has been received."
- Give next steps: "We'll get back to you within 24 hours."
- Offer a way back: CTA to home or next logical page
- Optional: social sharing or WhatsApp follow-up button

---

## 5. SEO & Technical Files
*Always generated. These are not HTML pages but must be in the project root.*

| File | Purpose | Template |
|------|---------|----------|
| `sitemap.xml` | Lists all indexable pages for Google | See below |
| `robots.txt` | Tells crawlers what to index | See below |
| `manifest.json` | PWA manifest — enables "Add to Home Screen" | See below |
| `humans.txt` | Credits the team — humanises the site | See below |
| `security.txt` | Security contact disclosure | See below |
| `.htaccess` | Apache redirect and error page rules | See below |
| `favicon.svg` | SVG favicon — scalable, modern | Generate from brand |
| `og-image.jpg` | 1200×630 Open Graph share image | Use brand image |

### sitemap.xml Template
```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://{domain}/</loc>
    <lastmod>{YYYY-MM-DD}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://{domain}/about</loc>
    <lastmod>{YYYY-MM-DD}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  <!-- Add one <url> block per public page -->
</urlset>
```

### robots.txt Template
```
User-agent: *
Allow: /

Disallow: /admin/
Disallow: /private/
Disallow: /thank-you
Disallow: /unsubscribe
Disallow: /link-expired

Sitemap: https://{domain}/sitemap.xml
```

### manifest.json Template
```json
{
  "name": "{Business Name}",
  "short_name": "{Short Name}",
  "description": "{Business tagline}",
  "start_url": "/",
  "display": "standalone",
  "background_color": "{primary_bg_color}",
  "theme_color": "{primary_brand_color}",
  "icons": [
    { "src": "/icons/icon-192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "/icons/icon-512.png", "sizes": "512x512", "type": "image/png" }
  ]
}
```

### humans.txt Template
```
/* TEAM */
Agency: Tangison Agency
Site: https://tangison.com
AI-powered: Yes

/* TECHNOLOGY */
Languages: HTML, CSS, JavaScript
Framework: Vanilla / React / Next.js
AI: Claude by Anthropic

/* NOTE */
This site was crafted with care by Tangison Agency, Windhoek, Namibia.
```

### security.txt Template
```
Contact: mailto:{security_email}
Expires: {1 year from build date}
Preferred-Languages: en
```

### .htaccess Template (Apache)
```apache
# Error pages
ErrorDocument 404 /404.html
ErrorDocument 403 /403.html
ErrorDocument 500 /500.html
ErrorDocument 503 /503.html

# Force HTTPS
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Remove trailing slash
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)/$ /$1 [R=301,L]

# Cache static assets
<FilesMatch "\.(ico|jpg|jpeg|png|gif|svg|css|js|woff2)$">
  Header set Cache-Control "max-age=31536000, public"
</FilesMatch>

# Security headers
Header always set X-Content-Type-Options "nosniff"
Header always set X-Frame-Options "SAMEORIGIN"
Header always set Referrer-Policy "strict-origin-when-cross-origin"
```

---

## 6. Auth Pages (Conditional)
*Generate only if site requires login/registration.*

| Page | File | Notes |
|------|------|-------|
| Login | `login.html` | Email + password, "remember me", forgot password link |
| Register | `register.html` | Name, email, password, terms checkbox |
| Forgot Password | `forgot-password.html` | Email field, send reset link |
| Reset Password | `reset-password.html` | New password + confirm |
| Verify Email | `verify-email.html` | "Check your inbox" confirmation state |
| Account | `account.html` | Profile settings stub |

---

## 7. E-Commerce Pages (Conditional)
*Generate only if site sells products.*

| Page | File | Notes |
|------|------|-------|
| Shop / Store | `shop.html` | Product grid |
| Product Detail | `product.html` | Single product, images, add to cart |
| Cart | `cart.html` | Line items, totals, proceed to checkout |
| Checkout | `checkout.html` | Shipping, payment |
| Order Confirmation | `order-confirmation.html` | Receipt / thank you |
| Returns Policy | `returns.html` | Legal page |
| Shipping Info | `shipping.html` | Delivery info |

---

## 8. Blog / Content Pages (Conditional)
*Generate only if site has editorial content.*

| Page | File | Notes |
|------|------|-------|
| Blog Index | `blog/index.html` | Article grid with categories |
| Article Template | `blog/article.html` | Single post with author, date, tags |
| Category | `blog/category.html` | Filtered article list |
| Author | `blog/author.html` | Author bio + their posts |

---

## Page Status Labels

When reporting the page plan to the user, label each page:

- `[FULL]` — Complete content generated
- `[STUB]` — Minimal placeholder, correct structure, on-brand
- `[SKIP]` — Not applicable to this project (explain why)
- `[CLIENT]` — Awaiting client content to complete
