# AI Agent Embed — Tangison Standard
**Every Tangison website ships with an embedded AI assistant powered by Claude.**

---

## Overview

The embedded agent is a floating chat widget that:
- Lives bottom-right on every page
- Knows the business: name, services, contact, FAQ, location
- Answers visitor questions in real time via Anthropic API
- Escalates to WhatsApp or email when it can't help
- Is styled to match the site's brand colours exactly
- Is labelled as AI (honest and compliant)

---

## Implementation

### 1. Add to `<head>` (every page)

```html
<!-- AI Agent styles -->
<style id="tangison-agent-styles">
  #tangison-agent-bubble {
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 9999;
    font-family: inherit;
  }

  .agent-toggle {
    width: 56px;
    height: 56px;
    border-radius: 50%;
    background: var(--primary, #2C4A1E);
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    border: none;
    box-shadow: 0 4px 20px rgba(0,0,0,0.2);
    transition: transform 0.2s, box-shadow 0.2s;
  }

  .agent-toggle:hover {
    transform: scale(1.05);
    box-shadow: 0 6px 28px rgba(0,0,0,0.25);
  }

  .agent-window {
    display: none;
    position: absolute;
    bottom: 70px;
    right: 0;
    width: 340px;
    height: 480px;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 8px 40px rgba(0,0,0,0.18);
    border: 1px solid rgba(0,0,0,0.08);
    flex-direction: column;
    overflow: hidden;
  }

  .agent-window.open { display: flex; }

  .agent-header {
    background: var(--primary, #2C4A1E);
    color: #fff;
    padding: 16px;
    display: flex;
    align-items: center;
    gap: 10px;
    flex-shrink: 0;
  }

  .agent-header-dot {
    width: 8px;
    height: 8px;
    background: #4ade80;
    border-radius: 50%;
    animation: pulse 2s infinite;
  }

  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.4; }
  }

  .agent-header-info { flex: 1; }
  .agent-header-name { font-weight: 500; font-size: 14px; }
  .agent-header-sub { font-size: 11px; opacity: 0.75; }

  .agent-close {
    background: none;
    border: none;
    color: #fff;
    cursor: pointer;
    opacity: 0.75;
    font-size: 18px;
    padding: 4px;
    line-height: 1;
  }

  .agent-messages {
    flex: 1;
    overflow-y: auto;
    padding: 16px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    scroll-behavior: smooth;
  }

  .agent-msg {
    max-width: 85%;
    padding: 10px 13px;
    border-radius: 12px;
    font-size: 13px;
    line-height: 1.5;
  }

  .agent-msg.bot {
    background: #f3f4f6;
    color: #1f2937;
    border-radius: 4px 12px 12px 12px;
    align-self: flex-start;
  }

  .agent-msg.user {
    background: var(--primary, #2C4A1E);
    color: #fff;
    border-radius: 12px 4px 12px 12px;
    align-self: flex-end;
  }

  .agent-msg.typing {
    background: #f3f4f6;
    color: #9ca3af;
    align-self: flex-start;
    font-size: 18px;
    letter-spacing: 4px;
    padding: 8px 13px;
  }

  .agent-input-area {
    padding: 12px;
    border-top: 1px solid #e5e7eb;
    display: flex;
    gap: 8px;
    flex-shrink: 0;
  }

  .agent-input {
    flex: 1;
    border: 1px solid #e5e7eb;
    border-radius: 20px;
    padding: 8px 14px;
    font-size: 13px;
    outline: none;
    transition: border-color 0.2s;
    font-family: inherit;
  }

  .agent-input:focus { border-color: var(--primary, #2C4A1E); }

  .agent-send {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: var(--primary, #2C4A1E);
    color: #fff;
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    transition: opacity 0.2s;
  }

  .agent-send:hover { opacity: 0.85; }
  .agent-send:disabled { opacity: 0.4; cursor: not-allowed; }

  .agent-disclaimer {
    text-align: center;
    font-size: 10px;
    color: #9ca3af;
    padding: 6px 12px 10px;
  }

  @media (max-width: 480px) {
    .agent-window {
      width: calc(100vw - 32px);
      right: -8px;
      bottom: 68px;
    }
  }
</style>
```

### 2. Add Widget HTML (before `</body>`)

```html
<!-- Tangison AI Agent Widget -->
<div id="tangison-agent-bubble">
  <div class="agent-window" id="agentWindow">
    <div class="agent-header">
      <div class="agent-header-dot"></div>
      <div class="agent-header-info">
        <div class="agent-header-name">{Business Name} Assistant</div>
        <div class="agent-header-sub">AI-powered · Usually replies instantly</div>
      </div>
      <button class="agent-close" onclick="toggleAgent()" aria-label="Close chat">✕</button>
    </div>

    <div class="agent-messages" id="agentMessages">
      <!-- Initial greeting injected by JS -->
    </div>

    <div class="agent-disclaimer">Powered by AI · May make mistakes</div>

    <div class="agent-input-area">
      <input
        type="text"
        class="agent-input"
        id="agentInput"
        placeholder="Ask me anything..."
        maxlength="500"
        autocomplete="off"
      >
      <button class="agent-send" id="agentSend" aria-label="Send message">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <line x1="22" y1="2" x2="11" y2="13"></line>
          <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
        </svg>
      </button>
    </div>
  </div>

  <button class="agent-toggle" onclick="toggleAgent()" aria-label="Open AI assistant">
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
    </svg>
  </button>
</div>
```

### 3. JavaScript (before `</body>`, after widget HTML)

Customise the `AGENT_CONFIG` block for each client. Everything else is reusable.

```html
<script>
// ============================================================
// TANGISON AI AGENT — CONFIGURE THIS BLOCK PER CLIENT
// ============================================================
const AGENT_CONFIG = {
  businessName: "{Business Name}",
  greeting: "Hi! I'm the {Business Name} assistant. How can I help you today?",
  systemPrompt: `You are a helpful AI assistant for {Business Name}, a {industry} business based in {location}.

Your role: Answer questions from website visitors about the business, its products/services, pricing, location, and contact details. Be friendly, concise, and professional.

About the business:
- Name: {Business Name}
- Industry: {industry}
- Location: {location}
- Products/Services: {list key offerings}
- Contact email: {email}
- Phone/WhatsApp: {phone}
- Hours: {hours}

Key facts to know:
{add 5–8 bullet points of important business facts}

If you cannot answer a question confidently, say: "I'm not sure about that — please contact us directly at {email} or WhatsApp {phone} and our team will help you."

Keep responses under 3 sentences unless the question clearly requires more detail.
Do not make up prices, availability, or facts not provided above.
Do not discuss competitors.`,
  escalationEmail: "{email}",
  escalationWhatsApp: "{phone}",
  primaryColor: "{primary_color}"
};
// ============================================================

// State
let agentOpen = false;
let agentHistory = [];
let agentLoading = false;

// Toggle chat window
function toggleAgent() {
  agentOpen = !agentOpen;
  const win = document.getElementById('agentWindow');
  win.classList.toggle('open', agentOpen);
  if (agentOpen && agentHistory.length === 0) {
    addMessage('bot', AGENT_CONFIG.greeting);
  }
  if (agentOpen) {
    setTimeout(() => document.getElementById('agentInput').focus(), 100);
  }
}

// Add message to UI
function addMessage(role, text) {
  const container = document.getElementById('agentMessages');
  const msg = document.createElement('div');
  msg.className = `agent-msg ${role}`;
  msg.textContent = text;
  container.appendChild(msg);
  container.scrollTop = container.scrollHeight;
  if (role !== 'typing') {
    agentHistory.push({ role: role === 'user' ? 'user' : 'assistant', content: text });
  }
  return msg;
}

// Typing indicator
function showTyping() {
  return addMessage('typing', '···');
}

// Send message to Anthropic API
async function sendMessage() {
  const input = document.getElementById('agentInput');
  const text = input.value.trim();
  if (!text || agentLoading) return;

  input.value = '';
  agentLoading = true;
  document.getElementById('agentSend').disabled = true;

  addMessage('user', text);
  const typingEl = showTyping();

  try {
    const messages = [
      ...agentHistory.slice(0, -1), // exclude the message we just added (it's already in history)
    ];

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: AGENT_CONFIG.systemPrompt,
        messages: [
          ...agentHistory.filter((_, i) => i < agentHistory.length - 1),
          { role: 'user', content: text }
        ]
      })
    });

    const data = await response.json();
    typingEl.remove();

    if (data.content && data.content[0]) {
      addMessage('bot', data.content[0].text);
    } else {
      addMessage('bot', `Sorry, something went wrong. Please contact us at ${AGENT_CONFIG.escalationEmail}`);
    }
  } catch (err) {
    typingEl.remove();
    addMessage('bot', `I'm having trouble connecting. Please try WhatsApp: ${AGENT_CONFIG.escalationWhatsApp}`);
  } finally {
    agentLoading = false;
    document.getElementById('agentSend').disabled = false;
    input.focus();
  }
}

// Enter key to send
document.getElementById('agentInput').addEventListener('keydown', function(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});
document.getElementById('agentSend').addEventListener('click', sendMessage);
</script>
```

---

## Customisation Per Client

When generating the widget for a new client, fill in `AGENT_CONFIG`:

| Field | Source | Example |
|-------|--------|---------|
| `businessName` | Client brief | `"Tuliikeni Oil Solutions"` |
| `greeting` | Auto-generate | `"Hi! I'm the Tuliikeni assistant..."` |
| `systemPrompt` | Full brief + page content | See pattern above |
| `escalationEmail` | Client brief | `"info@tuliikeni.com"` |
| `escalationWhatsApp` | Client brief | `"+264810614182"` |
| `primaryColor` | Design system | `"#2C4A1E"` |

The system prompt should include:
- Everything from the About page
- All products/services with brief descriptions
- Opening hours if relevant
- Pricing if publicly available
- FAQs if available
- Return policy / delivery info if e-commerce

---

## API Key Note

The Anthropic API key is handled server-side or via environment variables.
For static sites, a simple proxy endpoint is recommended:

```
POST /api/chat  →  proxies to Anthropic API with key stored in env
```

Never expose the API key in frontend JavaScript in production.
For development/demo builds, the key can be passed via a config file not committed to git.

---

## Accessibility

- Toggle button has `aria-label="Open AI assistant"`
- Close button has `aria-label="Close chat"`
- Input has `placeholder` and is focusable
- Window is announced via ARIA when opened (add `role="dialog"` and `aria-label` in production)
