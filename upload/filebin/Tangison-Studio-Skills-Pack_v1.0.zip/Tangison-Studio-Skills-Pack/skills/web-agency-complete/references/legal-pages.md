# Legal Pages — Tangison Standard
**Pre-written, fill-in-the-blank legal pages. Never leave these blank.**

---

## Rules
- Always fill: business name, email, date, location
- Always link from every footer
- Mark with `Last updated: {date}`
- Use POPIA language for Namibian/South African clients (alongside GDPR concepts)
- These are good-faith standard pages — client should get legal review for high-risk businesses

---

## Privacy Policy (Standard Template)

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Privacy Policy | {Business Name}</title>
  <!-- [include full site head: fonts, favicon, css] -->
</head>
<body>
  <!-- [site nav] -->

  <main class="legal-page">
    <div class="legal-container">
      <h1>Privacy Policy</h1>
      <p class="legal-meta">Last updated: {Month Day, Year}</p>

      <p>
        {Business Name} ("we", "us", or "our") is committed to protecting your personal information.
        This Privacy Policy explains how we collect, use, and safeguard your data when you visit
        our website at <a href="https://{domain}">{domain}</a>.
      </p>

      <h2>1. Information We Collect</h2>
      <p>We may collect the following types of information:</p>
      <ul>
        <li><strong>Contact information</strong>: name, email address, phone number — when you submit our contact form or place an order.</li>
        <li><strong>Usage data</strong>: pages visited, time on site, browser type — collected automatically via analytics tools.</li>
        <li><strong>Communications</strong>: messages you send us via email, WhatsApp, or our contact form.</li>
      </ul>

      <h2>2. How We Use Your Information</h2>
      <p>We use your information to:</p>
      <ul>
        <li>Respond to your enquiries and provide customer support</li>
        <li>Process orders and deliver products or services</li>
        <li>Send you relevant updates (only with your consent)</li>
        <li>Improve our website and services</li>
        <li>Comply with legal obligations</li>
      </ul>

      <h2>3. Data Sharing</h2>
      <p>
        We do not sell your personal data. We may share your information with trusted third-party
        service providers (such as payment processors or email platforms) strictly to operate our
        business. These parties are obligated to keep your data confidential.
      </p>

      <h2>4. Data Retention</h2>
      <p>
        We retain your personal data only for as long as necessary to fulfil the purposes outlined
        in this policy, or as required by law.
      </p>

      <h2>5. Your Rights</h2>
      <p>You have the right to:</p>
      <ul>
        <li>Access the personal data we hold about you</li>
        <li>Request correction of inaccurate data</li>
        <li>Request deletion of your data</li>
        <li>Opt out of marketing communications at any time</li>
        <li>Lodge a complaint with a relevant data protection authority</li>
      </ul>
      <p>To exercise these rights, contact us at <a href="mailto:{email}">{email}</a>.</p>

      <h2>6. Cookies</h2>
      <p>
        We use cookies to improve your browsing experience. Please see our
        <a href="/cookies">Cookie Policy</a> for full details.
      </p>

      <h2>7. Security</h2>
      <p>
        We implement appropriate technical and organisational measures to protect your
        personal data against unauthorised access, alteration, disclosure, or destruction.
      </p>

      <h2>8. Changes to This Policy</h2>
      <p>
        We may update this Privacy Policy from time to time. We will notify you of
        significant changes by updating the date at the top of this page.
      </p>

      <h2>9. Contact Us</h2>
      <p>
        If you have questions about this Privacy Policy, please contact us:<br>
        <strong>{Business Name}</strong><br>
        Email: <a href="mailto:{email}">{email}</a><br>
        Location: {address}
      </p>
    </div>
  </main>

  <!-- [site footer] -->
</body>
</html>
```

---

## Terms & Conditions (Standard Template)

```
<h1>Terms & Conditions</h1>
<p class="legal-meta">Last updated: {Month Day, Year}</p>

<p>
  By accessing or using the website at {domain}, you agree to be bound by these Terms & Conditions.
  If you do not agree, please do not use our site.
</p>

<h2>1. Use of Our Website</h2>
<p>
  You may use this website for lawful purposes only. You must not use it in any way that
  causes damage to the website, impairs availability, or violates any applicable law.
</p>

<h2>2. Intellectual Property</h2>
<p>
  All content on this site — including text, images, logos, and design — is owned by
  {Business Name} or its licensors and is protected by applicable intellectual property laws.
  You may not reproduce or distribute any content without written permission.
</p>

<h2>3. Products & Services</h2>
<p>
  We reserve the right to modify, suspend, or discontinue any product or service at any time
  without notice. Prices are subject to change.
</p>

<h2>4. Disclaimer of Warranties</h2>
<p>
  This website and its content are provided "as is" without any warranties, express or implied.
  We do not warrant that the site will be error-free or uninterrupted.
</p>

<h2>5. Limitation of Liability</h2>
<p>
  To the fullest extent permitted by law, {Business Name} shall not be liable for any indirect,
  incidental, or consequential damages arising from your use of this website or our products.
</p>

<h2>6. Third-Party Links</h2>
<p>
  Our site may contain links to third-party websites. We are not responsible for the content
  or privacy practices of those sites.
</p>

<h2>7. Governing Law</h2>
<p>
  These Terms are governed by the laws of {Country/Region}. Any disputes shall be subject
  to the exclusive jurisdiction of the courts of {City, Country}.
</p>

<h2>8. Changes</h2>
<p>
  We may update these Terms at any time. Continued use of the site after changes constitutes
  your acceptance of the revised Terms.
</p>

<h2>9. Contact</h2>
<p>
  Questions? Email us at <a href="mailto:{email}">{email}</a>.
</p>
```

---

## Cookie Policy (Short Version)

```
<h1>Cookie Policy</h1>
<p class="legal-meta">Last updated: {Month Day, Year}</p>

<p>
  This site uses cookies — small text files stored on your device — to improve your experience.
</p>

<h2>What cookies we use</h2>
<ul>
  <li><strong>Essential cookies</strong>: Required for the site to function. Cannot be disabled.</li>
  <li><strong>Analytics cookies</strong>: Help us understand how visitors use the site (e.g. Google Analytics). Anonymous data only.</li>
  <li><strong>Preference cookies</strong>: Remember your settings and choices.</li>
</ul>

<h2>Managing cookies</h2>
<p>
  You can control cookies through your browser settings. Disabling cookies may affect
  your experience on this site.
</p>

<p>For more information, see our <a href="/privacy">Privacy Policy</a>.</p>
```

---

## Legal Page CSS (add to main stylesheet)

```css
/* Legal pages */
.legal-page {
  padding: 8rem 2rem 5rem;
}

.legal-container {
  max-width: 740px;
  margin: 0 auto;
}

.legal-container h1 {
  font-family: var(--font-display, Georgia, serif);
  font-size: clamp(2rem, 4vw, 3rem);
  font-weight: 400;
  margin-bottom: 0.5rem;
  color: var(--primary);
}

.legal-meta {
  font-size: 0.85rem;
  color: #9ca3af;
  margin-bottom: 2.5rem;
  padding-bottom: 1.5rem;
  border-bottom: 1px solid #e5e7eb;
}

.legal-container h2 {
  font-size: 1.1rem;
  font-weight: 600;
  margin: 2.5rem 0 0.75rem;
  color: var(--primary);
}

.legal-container p {
  margin-bottom: 1rem;
  line-height: 1.8;
  color: #4b5563;
}

.legal-container ul {
  margin: 0.75rem 0 1rem 1.5rem;
}

.legal-container li {
  margin-bottom: 0.5rem;
  line-height: 1.7;
  color: #4b5563;
}

.legal-container a {
  color: var(--primary);
  border-bottom: 1px solid rgba(0,0,0,0.15);
}

.legal-container a:hover {
  border-bottom-color: var(--primary);
}
```
