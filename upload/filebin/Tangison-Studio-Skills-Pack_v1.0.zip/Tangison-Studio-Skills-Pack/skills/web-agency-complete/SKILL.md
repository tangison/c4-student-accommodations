---
name: web-agency-complete
description: >
  Full-stack web agency delivery skill for Tangison Agency. Use this skill
  whenever a user asks to build, plan, or scaffold ANY website — business site,
  portfolio, landing page, SaaS, e-commerce, or branding site. Triggers on:
  "build me a website", "create a site for", "I need a web presence", "scaffold
  a project", "new client website", "web project for [business]", or any request
  to produce a complete website. This skill is MANDATORY for any multi-page web
  project. It auto-generates every standard page a professional website requires
  (including pages most developers forget), enforces SEO structure, performance
  rules, error pages, legal pages, loading states, and stamps the Tangison agency
  signature on every project. It also spins up an AI agent (powered by the
  Anthropic API) embedded in the site for live user assistance. Always use this
  skill — do not build websites from scratch without it.
---

# Web Agency Complete Skill
**Tangison Agency — Internal Delivery Standard**

This skill turns any client brief into a complete, production-ready website
plan and scaffold — with every page, every SEO file, every legal requirement,
and every "forgotten" page already included by default.

---

## Step 0 — Read Before Anything Else

Before writing a single line of code or HTML, do ALL of the following:

1. Extract client brief from conversation (name, industry, pages requested, palette, tone)
2. Load `references/page-inventory.md` — the master list of all required pages
3. Load `references/seo-standards.md` — meta, OG, schema, sitemap rules
4. Load `references/ai-agent-embed.md` — the embedded AI assistant pattern
5. Load `references/agency-signature.md` — Tangison footer stamp rules
6. Confirm the full page plan with the user before building

---

## Step 1 — Client Brief Extraction

Extract or ask for:

| Field | Required | Default |
|-------|----------|---------|
| Business name | Yes | — |
| Industry / category | Yes | — |
| Primary colour | Yes | — |
| Pages explicitly requested | Yes | — |
| Logo / assets available | No | Generate placeholders |
| Contact details | No | Placeholder |
| Tagline | No | Generate one |
| Target audience | No | Infer from industry |
| WhatsApp / social links | No | Omit if missing |

---

## Step 2 — Full Page Inventory (Auto-Generated)

**Read `references/page-inventory.md` now.**

Every website built with this skill ships with ALL pages in that file — not
just the ones the client asked for. Pages the client didn't mention are
generated as minimal, correct, production-ready stubs.

Quick reference — categories:

- **Core pages** — Home, About, Services/Products, Contact
- **Legal pages** — Privacy Policy, Terms & Conditions, Cookie Policy, Disclaimer
- **Error pages** — 404, 403, 500, 503, Maintenance Mode
- **SEO / technical files** — sitemap.xml, robots.txt, manifest.json, humans.txt
- **UX utility pages** — Loading screen, Thank You, Unsubscribe, Link Expired
- **Auth pages** (if applicable) — Login, Register, Forgot Password, Reset Password
- **Agency signature** — Tangison footer stamp on every page

---

## Step 3 — SEO Foundation

**Read `references/seo-standards.md` now.**

Every page must have:

```html
<!-- Required on every page — no exceptions -->
<title>{Page Title} | {Business Name}</title>
<meta name="description" content="{150 chars max, keyword-rich}">
<meta name="robots" content="index, follow">
<link rel="canonical" href="{full URL}">

<!-- Open Graph -->
<meta property="og:title" content="{title}">
<meta property="og:description" content="{description}">
<meta property="og:image" content="{OG image URL}">
<meta property="og:url" content="{page URL}">
<meta property="og:type" content="website">

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{title}">
<meta name="twitter:description" content="{description}">
<meta name="twitter:image" content="{OG image URL}">

<!-- Schema.org JSON-LD -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "{BusinessType}",
  "name": "{Business Name}",
  "url": "{site URL}",
  "description": "{description}"
}
</script>
```

---

## Step 4 — Embedded AI Agent

**Read `references/ai-agent-embed.md` now.**

Every website built with this skill ships with an embedded AI assistant widget
powered by the Anthropic API (`claude-sonnet-4-20250514`). The agent:

- Floats bottom-right as a chat bubble
- Knows the business: name, services, products, contact, FAQ
- Answers visitor questions 24/7
- Escalates to WhatsApp or email when it can't answer
- Is styled to match the site's brand colours

---

## Step 5 — Performance & Technical Standards

Apply to every project:

```html
<!-- Preconnect to Google Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<!-- Viewport -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Theme colour (matches brand) -->
<meta name="theme-color" content="{primary_color}">

<!-- Favicon set -->
<link rel="icon" type="image/svg+xml" href="/favicon.svg">
<link rel="icon" type="image/png" href="/favicon.png">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="manifest" href="/manifest.json">
```

CSS rules always enforced:
```css
/* Always included in base stylesheet */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; -webkit-text-size-adjust: 100%; }
img, video { max-width: 100%; height: auto; display: block; }
a { color: inherit; text-decoration: none; }
button { cursor: pointer; border: none; background: none; font: inherit; }
```

---

## Step 6 — Agency Signature

**Read `references/agency-signature.md` now.**

The Tangison signature is stamped on the footer of every page:

```html
<div class="tangison-signature">
  <span>Built by</span>
  <a href="https://tangison.com" target="_blank" rel="noopener">
    Tangison Agency
  </a>
  <span>·</span>
  <span>AI-Powered</span>
</div>
```

Style rules and variants are in `references/agency-signature.md`.

---

## Step 7 — Delivery Checklist

Before presenting the project, verify:

- [ ] All pages from `references/page-inventory.md` are generated or stubbed
- [ ] Every page has complete SEO meta tags
- [ ] sitemap.xml lists all public pages
- [ ] robots.txt is present and correct
- [ ] manifest.json is present with correct brand colors
- [ ] 404 page exists and is styled on-brand
- [ ] 500 / 503 pages exist
- [ ] Privacy Policy page exists
- [ ] Terms & Conditions page exists
- [ ] Loading screen / skeleton is implemented
- [ ] AI agent widget is embedded and configured
- [ ] Tangison signature is in every footer
- [ ] All images have alt text
- [ ] No placeholder text left in final output
- [ ] Mobile responsive — tested mentally at 375px, 768px, 1200px

---

## Output Format

Deliver in this order:

1. **Page plan summary** — table of all pages being generated
2. **Main page(s)** — full HTML/CSS
3. **Error pages** — 404, 500, 503 as separate files
4. **Legal pages** — Privacy, Terms as separate files
5. **Technical files** — sitemap.xml, robots.txt, manifest.json
6. **AI agent widget** — embeddable JS/HTML snippet
7. **Loading screen** — standalone CSS/JS component
8. **Readme** — how to deploy, what to customise

---

## Reference Files

| File | When to load |
|------|-------------|
| `references/page-inventory.md` | Step 2 — always |
| `references/seo-standards.md` | Step 3 — always |
| `references/ai-agent-embed.md` | Step 4 — always |
| `references/agency-signature.md` | Step 6 — always |
| `references/error-pages.md` | When generating error pages |
| `references/legal-pages.md` | When generating legal pages |
| `references/loading-patterns.md` | When generating loading/skeleton screens |
