---
name: tangison-web-audit
description: Comprehensive web and code quality audit — Performance and Core Web Vitals, Accessibility, SEO, Security/Best Practices, Agentic Browsing, theming/design-token consistency, responsive design, AI-generated-look anti-patterns, and a separate over-engineering/complexity pass. Use whenever asked to audit, review, or quality-check a live site or codebase — before launch, after major changes, or on request. Distinguishes measured runtime evidence from source-code hypotheses; never treats an aggregate score as proof of quality on its own.
---

# Tangison Web & Code Quality Audit

Two audit passes live here, run separately: the **quality audit** (correctness of the experience — performance, accessibility, SEO, security, design consistency) and the **complexity audit** (is the code simpler than it needs to be). They answer different questions and use different report formats — don't blend them into one report.

## Quality audit

### How it works

1. Establish the audit target: representative URLs, important states/journeys, public vs authenticated access, mobile/desktop scope.
2. If the page can run, collect a minimal live baseline before searching the codebase broadly. Use runtime failures to localize where to look in source — don't start from a broad code read.
3. Keep measured findings (you observed it) separate from hypotheses (you inferred it from reading code) throughout.
4. Categorize by user impact and confidence, then make or recommend specific fixes.
5. Re-run the equivalent checks after fixes. Report what's now verified vs what still needs field or human validation.

### Tool routing

Use the best capability already available; don't block the audit on optional setup you don't have.

| Need | Preferred route | Fallback |
|---|---|---|
| Performance / Core Web Vitals | A recorded browser performance trace with focused insights (Chrome DevTools MCP if connected) | Lighthouse CLI or PageSpeed Insights lab data |
| Real-user performance | CrUX values from a current trace summary | PageSpeed Insights / CrUX Vis |
| Accessibility, SEO, Best Practices, Agentic Browsing | A live Lighthouse audit (Chrome DevTools MCP if connected) | Category-specific Lighthouse CLI audits plus manual checks |
| Rendered semantics / interaction | Accessibility-tree inspection and UI exercise (Chrome DevTools MCP if connected) | Manual browser testing |
| Site-wide rule-based crawl (230+ rules across SEO/perf/security/a11y/content) | `squirrel audit <url> --format llm` if the squirrel CLI is installed | Skip this route; cover the same ground with Lighthouse + manual checks below |

If a tool isn't available, don't stall on it — fall back and say which route was actually used, since that affects how much weight the finding carries.

### Dimensions

**Performance — Core Web Vitals must pass:**
- LCP < 2.5s — optimize images, fonts, server response time.
- INP < 200ms — reduce JS execution time, break up long tasks.
- CLS < 0.1 — explicit dimensions on images, embeds, ads.
- Resource optimization: compressed/modern-format images with srcset, minimal and code-split JS, critical CSS extracted, `font-display: swap` with preloaded critical fonts.
- Loading strategy: preconnect to third-party origins, preload LCP-critical assets, lazy-load below-fold content, long cache TTLs on hashed static assets.
- Stays inside the standing sub-500KB page-transfer budget (per `tech-stack`) — this is Tangison's own bar on top of the generic thresholds above.

**Accessibility (WCAG AA baseline):**
- Perceivable: meaningful alt text (empty alt for decorative), 4.5:1 contrast for normal text / 3:1 for large text, never color alone, captions/transcripts for media.
- Operable: full keyboard access with no traps, visible focus indicators, skip links, no forced auto-advancing content.
- Understandable: `lang` attribute set, consistent navigation, form errors clearly associated with fields, all inputs labeled.
- Robust: valid HTML (no duplicate IDs, proper nesting), ARIA used correctly and only where native elements can't do the job.

**SEO:**
- Crawlability: valid robots.txt, complete XML sitemap, canonical URLs, no accidental noindex on important pages.
- On-page: unique descriptive titles, page-specific meta descriptions, logical heading hierarchy (more than one `<h1>` isn't itself a failure), descriptive link text (not "click here").
- Technical: responsive with ≥48px tap targets, HTTPS, structured data (JSON-LD) where it fits the content type. Field Core Web Vitals are evidence of page experience — don't promise a ranking change from fixing them.

**Security / Best Practices:**
- HTTPS everywhere, no mixed content, HSTS, no known-vulnerable dependencies, CSP headers, no exposed source maps in production.
- No deprecated APIs (`document.write`, sync XHR), valid doctype, charset declared first in `<head>`, clean console with no CORS errors.
- No intrusive interstitials (especially mobile), permission requests only with context, buttons that do what they say.

**Agentic Browsing** (how well assistants can use the page):
- Semantic HTML with proper labels/names/roles/states exposed in the accessibility tree is the actual signal here — this overlaps heavily with the Accessibility dimension by design.
- A registered WebMCP integration, if present, is reviewed for real tool/schema/form coverage — never added purely to raise a score.
- `llms.txt`, if present, is optional and doesn't prove ingestion by any AI product. Keep this dimension separate from SEO claims — agentic browsability isn't search ranking evidence.

**Theming (design-token consistency):**
- Hard-coded colors instead of design tokens, missing or broken dark-mode variants, mixed token types, values that don't update on theme switch.

**Responsive design:**
- Fixed widths that break on mobile, touch targets under 44×44px, horizontal overflow on narrow viewports, layouts that break under text-size scaling, missing breakpoints.

**AI-generated-look anti-patterns** — treat this as its own critical check, not a minor note:
- The generic "AI palette," gradient text, glassmorphism, hero metrics, uniform card grids, default system fonts, gray text on colored backgrounds, nested cards, bounce easing, copy that just restates the heading. Call it out plainly if the page reads as templated rather than art-directed — this is the same standard `frontend-design` already holds work to.

### Severity

| Level | Description | Action |
|---|---|---|
| Critical | Security vulnerabilities, complete failures, 5+ AI-slop tells | Fix immediately |
| High | Core Web Vitals failures, major a11y barriers (WCAG AA violations), 3–4 AI-slop tells | Fix before launch |
| Medium | Performance opportunities, SEO improvements, 1–2 AI-slop tells | Fix within the current work cycle |
| Low | Minor optimizations, code-quality nits, subtle polish | Fix when convenient |

### Report format

```
## Audit results

### Evidence
| Signal | Scope/conditions | Result | Source |
|---|---|---|---|
| LCP | URL, mobile | 3.1s (needs improvement) | trace / Lighthouse |
| Accessibility | URL, mobile nav | 92 | Lighthouse |

### AI-generated-look verdict
Pass/fail, specific tells named, brutally honest — this comes first, not buried.

### Critical issues (X found)
- **[Category]** Issue. Location: `path/to/file:line` or URL/component.
  - **Impact:** why this matters to a real user
  - **Evidence:** measured failure, runtime observation, or source hypothesis (label which)
  - **Fix:** specific, actionable change

### High / Medium / Low
(same shape as above, grouped by severity)

### Patterns
Recurring problems suggesting a systemic gap rather than a one-off ("hard-coded colors in 15+ components").

### Positive findings
What's genuinely working — don't skip this.

### Summary
Per-dimension status and finding counts.

### Recommended priority
1. Fix this first because...
2. Then...

### Verification
What's re-confirmed post-fix, what's still pending field/human validation.
```

### Rules

Every issue gets an impact explanation — never report a finding without saying why it matters. Recommendations are specific, not generic ("preload the LCP image at `/hero.webp`," not "improve loading"). Don't skip positive findings. Don't let everything be Critical — prioritize ruthlessly, and too many Low-severity notes is noise, not thoroughness. Verify a finding before reporting it as fact; flag suspected-but-unconfirmed issues as hypotheses.

### Cadence

Before every deploy: Core Web Vitals passing, no a11y errors, no console errors, HTTPS working, meta tags present. Weekly: Search Console issues, Core Web Vitals trend, dependency updates, a screen-reader pass. Monthly: full audit across every dimension above plus a real-user accessibility check.

## Complexity audit (separate, optional pass)

A distinct, narrower scan — run it separately from the quality audit above, and don't blend the two reports. Scope: over-engineering and unnecessary complexity only. Correctness bugs, security holes, and performance are explicitly out of scope here — those belong in the quality audit above or a normal `tangison-systematic-debugging` pass.

Hunt for: dependencies doing what the standard library or platform already ships; interfaces with a single implementation; factories producing one product; wrapper functions that only delegate; files exporting exactly one thing; dead flags and unused config; hand-rolled reimplementations of stdlib functions; same logic expressible in fewer lines.

Tag every finding:
- `delete` — dead code, unused flexibility, speculative feature. Replacement: nothing.
- `stdlib` — hand-rolled thing the standard library ships. Name the function.
- `native` — a dependency doing what the platform already does. Name the platform feature.
- `yagni` — abstraction with one implementation, config nobody sets, a layer with one caller.
- `shrink` — same logic, fewer lines. Show the shorter form.

Output: one line per finding, ranked biggest cut first: `<tag> <what to cut>. <replacement>. [path]`. End with `net: -N lines, -M deps possible`. If nothing qualifies: say so plainly — "Lean already. Ship." — don't manufacture findings to fill the report.

This pass lists findings and applies nothing on its own — treat it as one-shot unless asked to also apply the cuts.
