---
name: tangison-find-skills
description: Wraps Vercel's find-skills. Given a task, finds, ranks, vets and installs the best skills, then loops with a blind critic until every part of the task is covered, with proof. Use when starting a large or unfamiliar job, or when told "find skills".
---

# Tangison Find Skills

TASK: [TASK]

1. Bootstrap. Run npx skills use "https://github.com/vercel-labs/skills" --skill "find-skills" > /tmp/fs.txt 2>&1. If it errors, try npx skills add https://github.com/vercel-labs/skills --skill find-skills. If that fails, fetch its SKILL.md from GitHub. Read the whole output and follow it.
2. Local first. List installed skills and use any that already cover the task. Search outside only for gaps.
3. Split TASK into 3 to 7 capabilities. Write them in skills-ledger.md, each with a test for "covered".
4. Hunt. For each gap run 2 to 3 different searches: npx skills find "<keywords>". Check the skills.sh leaderboard for trending and most installed. Never invent a skill, install count or URL.
5. Pick the top 1 per gap (max 5 per round). Score: relevance 40, popularity 20, source trust 20, recent 10, fits Tangison rules 10.
6. Vet. Read the full SKILL.md first. Reject it if it runs remote scripts, wants credentials, sends data out, or overrides Tangison rules. Unsure means do not install.
7. Install, then list the skills folder. Paste the command output and folder listing into the ledger. No output means not done.
8. Critic. A fresh subagent sees only the TASK, the checklist and the installed skills, never your reasoning. It marks each capability covered or not and names the biggest gap. Harsh, no praise. No subagents: re-check from the checklist alone.
9. Loop. Repeat 4 to 8 on every gap, with new keywords each round. Exit when the critic marks all covered, a gap fails 3 rounds with 3 keyword sets (report it), or I say stop.
10. Ask me before: installing anything that failed vetting, anything needing payment or credentials, overwriting a skill.
11. Show a table (capability, skill, source, evidence, runner-up), then do the TASK.

Rules: Tangison skills win on branding, copy, format and delivery. Namibian context (N$, +264). Data first: figures sourced or labelled assumption. Never fabricate proof. Real client logos only. No em dashes. Complete output.
