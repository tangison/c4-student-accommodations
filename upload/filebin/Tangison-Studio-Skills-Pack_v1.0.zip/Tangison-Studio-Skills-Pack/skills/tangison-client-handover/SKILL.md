---
name: tangison-client-handover
description: Builds the Tangison Studio client handover pack, a complimentary Digital Foundation Pack given to every client after a project. Includes a signed reference letter, company profile, brand kit, hosting and support notes, marketing plan, and templates. Delivered as branded PDF plus editable Word files. Use when a project is finished, a client needs a starter pack or marketing plan, or an established client needs a marketing refresh. Always in Namibian context, data first, using the brand assets from the site build.
---

# Tangison Client Handover

## 1. Intake gate (do first, never guess)
Confirm before building:
- Client name, industry, contact details, signatory name and title
- Track: Startup or Refresh
- Project scope actually delivered (website, marketing materials, strategy consultation, other)
- Next phase agreed or intended
- Site type: static or dynamic (database, admin, CMS)
- Who hosts: Tangison (default) or client
- Location of the site build's brand assets
- Signature: supplied signature image, or blank signature line
Missing item: ask once, or mark "TO CONFIRM". Never invent.

## 2. Branding rule (strict)
- Use the exact brand materials used when the site was built: logo files, hex codes, fonts, imagery, tone. Pull them from the site project (CSS variables, /assets, brand files).
- Client brand leads every document. Never impose Tangison styling on the client.
- Tangison appears only as a small "Prepared by Tangison Studio" line, using the Tangison Studio identity.
- If the build assets cannot be found, stop and ask. Never redraw, recreate or substitute a logo or colour.

## 3. Essentials (every client)
1. Closeout: what was delivered against scope, with a sign-off line
2. Reference letter (see section 5)
3. Company profile (use company-profile-code)
4. Brand kit one-pager, taken from the build
5. Hosting and maintenance note. Tangison-hosted static sites get one short paragraph: what is hosted, what is maintained, how to request changes. If the client self-hosts, add the asset and credential transfer list (domain, hosting, DNS, repo, analytics). List where logins live, never the passwords.
6. Renewal and running costs sheet in N$ (domain, hosting, SSL, email), with dates
7. Support terms: warranty window as agreed (ask, do not assume), change requests, response times
8. "If this happens, do this" page: site down, form not sending, email bouncing
9. Launch checklist results: SEO basics, analytics, forms tested, speed
10. Baseline scorecard: leads, enquiries, cost per lead, so the 90-day review has real numbers
11. 90-day next steps

Conditional: user guide and technical documentation ONLY if the site is dynamic (database, admin, CMS) or the client self-hosts. Then cover how to view and manage data, edit content, what never to touch, who to call. Static Tangison-hosted sites skip both.

## 4. Tracks
Startup adds:
- Namibian setup checklist (BIPA, NamRA, Social Security Commission, local licences), each item verified via research before inclusion
- 90-day marketing plan in N$, WhatsApp-first
- WhatsApp Business and Google Business Profile setup guide
- Monthly marketing rhythm, one page
- Templates: letterhead, business cards (print and digital), quote, invoice, flyer, email signature
Refresh adds:
- Marketing audit: what works, what leaks
- Competitor snapshot
- Quick wins and suggestions
- 30/60/90 refresh plan
- Monthly marketing rhythm, one page

## 5. Reference letter (required)
- One page, on the client's letterhead, using the client's build branding
- Written from the client, for Tangison Studio, confirming: Tangison Studio delivered [scope actually delivered], for a strong digital foundation, and the client intends to continue with Tangison Studio for the full digital and marketing setup [next phase from intake]
- Short copy, plain and specific, matched to the real project scope. No invented results, statistics or praise the client did not approve
- Signature block: name, title, company, date, signature. Use the supplied signature image exactly. If none, leave a clean blank signature line. Never generate or imitate a signature
- Optional Tangison Studio countersign line
- Issued only with the client's approval of the wording

## 6. Namibian context and data rules
- N$ currency, +264 phone format, local dates and holidays, local regulators
- Every figure needs a source and date, or is labelled "assumption"
- Research legal, tax and cost items with tangison-research before including them
- Never fabricate registration numbers, prices, testimonials, awards or client logos

## 7. Delivery
- Branded PDF pack (company-profile-code pipeline, visual check of every page)
- Editable .docx for the letter and templates
- Follow tangison-full-output-enforcement: complete output, no placeholders, no skipped sections

## 8. Writing rules
Plain language a business owner understands. No em dashes. No AI cliches ("take your business to the next level", "seamless solutions"). Specific beats impressive.

## 9. Final QC
- Client brand used, matches the site build
- Names, contacts, dates and N$ figures correct
- Reference letter matches the real scope and has its signature block
- Conditional guides only present when the site is dynamic or self-hosted
- Every claim sourced or labelled assumption
- PDF pages verified, .docx files open and edit cleanly
