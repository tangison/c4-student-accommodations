---
name: universal-flyer
description: Create, redesign, upscale, rewrite, edit, and produce finished marketing flyers and advertising graphics for any brand or client. Covers copywriting, visual strategy, branding, typography, image generation, reference matching, device mockups, social ads, service promotions, events, products, campaigns, and print/digital outputs.
---

# Universal Flyer

A flyer must make people:

**NOTICE → UNDERSTAND → TRUST → ACT**

Use strong copy, clear hierarchy, authentic branding, purposeful visuals, and precise production. Never produce generic AI-template designs.

## 1. CONTEXT

Inspect all available context, uploaded assets, references, and previous instructions.

Identify:

- Brand/client
- Logo and brand colours
- Fonts and visual identity
- Offer/product/service
- Audience
- Purpose
- Primary CTA
- Phone, email, website, socials
- Required dimensions
- Supplied photography/assets

Never invent missing business information.

## 2. FLYER MODE

Automatically determine:

**CREATE**: Build from the brief.

**REDESIGN**: Improve an existing flyer while preserving its strongest concept.

**UPSCALE**: Improve resolution, sharpness, typography, spacing, colour accuracy, imagery, and finish without unnecessarily changing the concept.

**COPY FIX**: Rewrite weak or confusing copy while preserving the visual design.

**BRAND ADAPTATION**: Apply another brand's real identity to an existing concept.

**REFERENCE MATCH**: Match the visual logic, hierarchy, composition, and quality of a reference without copying protected branding/content.

**CAMPAIGN SERIES**: Lock typography, colours, footer, grid, logo treatment, lighting, and visual language across multiple flyers.

## 3. COPY FIRST

Before designing, establish:

- What is being sold?
- Who is it for?
- What problem does it solve?
- What does the customer get?
- Why should they care?
- What should they do next?

Copy must match the actual offer.

Choose the most suitable framework:

| Use | Framework |
|---|---|
| General ad | AIDA |
| Problem-led | PAS |
| Transformation | BAB |
| Product/service | FAB |
| Headline | 4 U's |

### Headline

Make it clear, specific, short, and benefit-led.

Avoid:

- Generic slogans
- Empty buzzwords
- Fake urgency
- Unsupported claims
- Invented statistics
- Fake testimonials
- Corporate clichés

### Supporting copy

Explain the headline in 1–2 concise sentences.

Use:

**Offer + benefit + customer outcome**

### CTA

Use one primary action:

- WhatsApp Us
- Call Now
- Get A Quote
- Start Your Project
- Book A Consultation
- Visit Our Website
- Shop Now
- Register Today

Avoid weak CTAs such as "Click Here" or "Learn More" when a specific action is possible.

## 4. COPY-VISUAL CHECK

Before generation:

- Does the headline accurately describe the offer?
- Does the supporting copy explain it?
- Does the visual reinforce the message?
- Does the CTA logically follow?
- Would a stranger understand it within seconds?

If not, fix the copy/concept first.

## 5. BRAND ASSETS

Supplied assets are the source of truth.

Use exact:

- Logos
- Product images
- Photography
- Screenshots
- Packaging
- Icons
- Brand marks

Never redraw, reinterpret, distort, replace, or AI-regenerate supplied logos.

Never fabricate:

- Testimonials
- Statistics
- Awards
- Certifications
- Prices
- Addresses
- Partnerships
- Reviews
- Client logos
- Case studies
- Results
- Guarantees

## 6. BRAND SYSTEM

Never impose Tangison styling on another brand.

Match the client's actual identity.

Possible directions:

- Minimal corporate
- Luxury
- Industrial
- Beauty
- Technology
- Youth/lifestyle
- Institutional

Use:

**Base + primary accent + neutral**

Avoid uncontrolled colour palettes, unnecessary gradients, and decorative clutter.

## 7. TANGISON STUDIO MODE

When the flyer is for Tangison Studio:

**Colours**

- White `#FFFFFF`
- Atlantic Black `#111315`
- Terminal Black `#0A0B0C`
- Signal Teal `#2CB5B4`

**Typography**

- Headings: Cabinet Grotesk
- Body: Satoshi
- Metadata/URLs: JetBrains Mono

**Default contact**

`085 341 1522`

`studio.tangison.com`

Teal is an accent, not a replacement for the entire design.

## 8. FORMAT

Default:

**4:5 portrait**

Explicit user dimensions always override the default.

Examples:

- A4 → A4
- A3 → A3
- 1080×1350 → 4:5
- 1080×1920 → Story
- 1080×1080 → Square
- 1920×1080 → 16:9

Never silently change requested dimensions.

## 9. COMPOSITION

Use:

- One dominant focal point
- Strong hierarchy
- Asymmetry where appropriate
- Generous whitespace
- Deliberate cropping
- Scale contrast
- Clean alignment
- Clear visual rhythm

Avoid:

- Template-like cards
- Excessive borders
- Random shapes
- Decorative clutter
- Equal-size elements
- Unnecessary effects

## 10. VISUAL STRATEGY

The hero visual must support the offer.

Examples:

**Website:** Phone/laptop showing the real website.

**Construction:** Authentic workers, equipment, and site photography.

**Beauty:** Authentic supplied photography.

**Technology:** Devices and realistic interfaces.

**Product:** Realistic product hero.

**Event:** Strong event subject with clear typography.

Always ask:

**Why does this visual belong in this advertisement?**

## 11. DEVICE MOCKUPS

For phones, laptops, tablets, or monitors:

- Realistic perspective
- Correct screen integration
- Believable reflections
- Realistic shadows
- Correct bezel
- Physically coherent lighting

If UI is shown, define the important:

- Logo
- Navigation
- Heading
- CTA
- Image
- Colour system
- Layout

Keep small UI copy minimal.

## 12. 3D HERO OBJECTS

If an object emerges from a device:

**Make it physically emerge from the screen with correct perspective, believable contact, realistic depth, studio lighting, and accurate shadows.**

Avoid floating objects, impossible intersections, incorrect perspective, and screen obstruction.

## 13. PHOTOGRAPHY

Prefer authentic supplied photography.

Do not replace supplied photography unnecessarily.

Generated photography must match the real:

- Location
- Industry
- Environment
- People
- Clothing
- Architecture
- Lighting
- Cultural context

Avoid generic stock/AI imagery that feels disconnected from the market.

## 14. TYPOGRAPHY

Create clear hierarchy:

**1. Headline**

**2. Supporting copy**

**3. CTA**

**4. Contact**

**5. Metadata**

Use size, weight, tracking, line-height, and whitespace to create hierarchy.

Do not make everything bold.

## 15. REFERENCE REDESIGN

When a flyer is supplied:

**Same idea, better execution.**

Preserve the strongest:

- Composition
- Hero object
- Image concept
- Hierarchy
- Brand placement
- Proportions

Improve:

- Copy
- Typography
- Resolution
- Realism
- Alignment
- Spacing
- Colour accuracy
- Overall polish

Only completely redesign when requested.

## 16. UPSCALE

"Upscale" means more than enlarging pixels.

Improve:

- Resolution
- Sharpness
- Image clarity
- Typography
- Spacing
- Alignment
- Colour accuracy
- Logo quality
- Realism
- Overall finish

If the original copy is confusing or contradictory, rewrite it while preserving the visual concept.

## 17. IMAGE GENERATION

Build prompts from:

**Layout + Copy + Hero + Brand + Lighting + Background + CTA + Output**

Example:

> High-end 4:5 marketing advertisement. Clean white background, bold black headline reading exactly "[HEADLINE]". Concise supporting copy below reading "[SUPPORTING COPY]". Main hero visual showing [HERO]. Use the supplied logo and supplied photography exactly. Premium editorial composition, realistic lighting, controlled shadows, generous whitespace, strong hierarchy, sharp typography, brand-accurate colours. CTA: "[CTA]". Contact: "[CONTACT]". Render all supplied text exactly, with no typos, invented copy, distorted logos, or additional text.

## 18. REFERENCE IMAGE PROMPT

When editing from a reference:

> Use the attached flyer as the exact visual and composition reference. Preserve the overall hierarchy, proportions, hero placement, footer structure, visual balance, lighting, and brand treatment. Improve typography, clarity, resolution, realism, spacing, and finish. Replace only the requested copy and elements. Use supplied logos and photography exactly. Do not invent branding, claims, statistics, testimonials, or contact information.

## 19. MODEL ROUTING

**GPT Image**

Best for exact text, typography-heavy flyers, and clean graphic layouts.

**Nano Banana Pro**

Best for reference matching, photorealistic composites, devices, 3D objects, and campaign consistency.

**Nano Banana 2**

Best for rapid concepts and visual exploration.

Choose the model based on the hardest requirement.

## 20. EXACT TEXT

Important text has priority:

1. Headline
2. CTA
3. Phone
4. Website
5. Brand name
6. Supporting copy
7. Minor metadata

Never accept obvious text corruption.

If necessary, regenerate or create typography as a separate design layer.

## 21. FOOTER

Keep the footer simple:

**Contact | Website | Logo**

Example:

`WhatsApp 085 341 1522 | studio.tangison.com | TANGISON`

Do not overcrowd it.

## 22. SOCIAL READABILITY

Check the flyer at small size.

**3 seconds:** What is this?

**5 seconds:** Why should I care?

**10 seconds:** What should I do?

If any answer is unclear, fix the hierarchy.

## 23. NO AI CLICHÉS

Avoid phrases such as:

- Transform your business
- Take your business to the next level
- Unlock your potential
- Innovative solutions
- Cutting-edge solutions
- Empower your business
- Seamless solutions
- Revolutionise your business

Specific beats impressive-sounding.

## 24. NO EM DASHES

Never use em dashes.

Use commas, full stops, colons, parentheses, or line breaks.

## 25. FINAL QC

### Copy

- Correct spelling
- Correct grammar
- Accurate claims
- Clear headline
- Clear supporting copy
- Clear CTA
- No placeholders
- No fabricated claims
- No duplicate copy

### Contact

- Correct phone
- Correct WhatsApp
- Correct email
- Correct website
- Correct socials

### Brand

- Exact logo
- Correct proportions
- Correct colours
- No invented brand elements

### Layout

- Correct dimensions
- Safe margins
- No clipping
- No overlap
- Strong hierarchy
- Balanced whitespace
- CTA readable
- Contact readable

### Visual

- Sharp imagery
- Realistic objects
- Correct perspective
- Correct shadows
- No malformed hands
- No distorted devices
- No broken screen integration
- No AI artefacts
- No unnecessary decoration

### Typography

- Legible headline
- Correct hierarchy
- Correct spelling
- Clean line breaks
- No garbled text

## 26. FINAL STANDARD

Every flyer must pass:

**3-SECOND TEST:**  
Can I tell what it is?

**5-SECOND TEST:**  
Do I understand the value?

**10-SECOND TEST:**  
Do I know what to do next?

If not, redesign before delivery.

## 27. OUTPUT

When planning copy, provide:

### Flyer Concept
**Audience:**  
**Goal:**  
**Primary CTA:**  

### Headline Options
**A:** ...  
**B:** ...  
**C:** ...

### Recommended Headline
**...**

### Supporting Copy
**...**

### CTA
**...**

### Contact
**...**

### Visual Direction
**...**

### Layout
**...**

### Brand Treatment
**...**

## FINAL RULE

Do not ask unnecessary questions when the available brief and assets are sufficient.

When the user asks to create, redesign, upscale, rewrite, improve, or generate a flyer:

**Understand the offer → fix the copy → choose the visual strategy → preserve authentic assets → design the hierarchy → generate/edit → QC → deliver.**

The goal is always:

**Clear copy. Strong visual. Real branding. One action. No AI slop.**
