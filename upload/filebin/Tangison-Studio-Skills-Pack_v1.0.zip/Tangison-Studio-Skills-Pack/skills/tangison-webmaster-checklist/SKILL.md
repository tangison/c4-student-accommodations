---
name: tangison-webmaster-checklist
description: The standing pre-launch checklist for every website Tangison Studio builds — footer credit, sitemaps, brand page, metadata/OG/structured data, SEO basics, mandatory pages, writing/anti-AI-slop standards, performance budget, accessibility, and demo-vs-full access mode. Use before calling any build done, whether it's a full Tangison-built site or work handed off from tangison-web-content/tangison-web-create. wearecollins.com is the standing design/quality bar every Studio delivery is held against.
---

# Tangison Webmaster Checklist

The bar for every Studio delivery is **wearecollins.com** — not a vague "high quality," a named, fetchable, comparable reference. When judging whether a build is good enough, compare it against Collins directly (screenshot both, side by side), not against a description of what Collins does. This applies to overall design quality and craft; it doesn't override the specific Tangison brand rules below (Studio's own palette, entity routing, etc.) — Collins is the bar for *how well-made it feels*, not a license to borrow its visual identity.

Run this checklist before any build is called done — full production site or demo.

## Credit & footer

- [ ] "Made by Tangison Studio" — visible, linked to `studio.tangison.com`, on every public page, unless the client explicitly asked for it removed for that project
- [ ] Footer contact info matches the correct issuing entity (Studio vs Technologies vs client)
- [ ] Copyright line present, current year

## Discoverability / SEO

- [ ] `robots.txt` present and correct — not blocking anything important
- [ ] `sitemap.xml` present and submitted to Search Console
- [ ] Canonical URLs set; no accidental duplicate-content paths
- [ ] Unique meta title + meta description on every page, not truncated
- [ ] Open Graph tags (`og:title`, `og:description`, `og:image`, `og:url`) on every page
- [ ] Twitter/X card tags
- [ ] Full favicon set (all sizes)
- [ ] Structured data / JSON-LD where it genuinely fits (Organization, Product, FAQ, etc.) — validated against the actual visible content, never fabricated
- [ ] Any preview/demo/staging URL marked `noindex` so it can't leak into search

## Mandatory pages

- [ ] `/brand` page — public, written from `BRAND.md`, approved copy only
- [ ] Privacy policy
- [ ] Terms of service (if the site takes payments, accounts, or user data)
- [ ] Cookie/consent notice (if analytics or tracking cookies are in use)
- [ ] 404 page
- [ ] 500 / error page
- [ ] Offline / maintenance page, if relevant to how the site is hosted

## Content & writing standards

- [ ] Zero em dashes
- [ ] No generic AI phrasing ("in today's fast-paced world," "unlock your potential," "seamless," "cutting-edge," "unwavering commitment," etc.)
- [ ] No AI-slop visual patterns — generic gradient hero, glassmorphism without purpose, uniform card grids, default system fonts, gray-on-color text
- [ ] Every fact (name, price, contact, date, policy) matches the approved source exactly — no drift from the fact ledger
- [ ] No fabricated testimonials, stats, awards, or client names

## Performance

- [ ] Sub-500KB page-transfer budget for 3G — checked explicitly per page, not folded into one generic score
- [ ] Core Web Vitals: LCP < 2.5s, INP < 200ms, CLS < 0.1
- [ ] Caching strategy set — long TTL on hashed static assets
- [ ] Images in WebP/AVIF, lazy-loaded below the fold, served at correct dimensions
- [ ] HTTPS everywhere, no mixed content

## Accessibility

- [ ] WCAG AA: contrast, full keyboard navigation, visible focus states, alt text, labeled form inputs
- [ ] Skip-to-content link present

## Access / build mode

- [ ] Demo mode: only approved pages unlocked (home, brand, privacy-type pages); everything else locked and genuinely unbypassable
- [ ] Full mode: everything unlocked; no leftover locked or placeholder routes

## Final gate

- [ ] Collins-bar comparison done — side by side, named and fetched, not described from memory
- [ ] Hallmark anti-slop verdict surfaced first in the audit report, before findings-by-severity
- [ ] No unresolved P0/P1 issues remain

Anything on this list that's missing at review time blocks sign-off — it doesn't get waved through as a follow-up task unless the user explicitly accepts the gap with a stated reason.
