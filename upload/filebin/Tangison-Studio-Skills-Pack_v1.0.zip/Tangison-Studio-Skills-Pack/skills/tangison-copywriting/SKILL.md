---
name: tangison-copywriting
description: Write or rewrite persuasive marketing copy — landing pages, homepages, pricing pages, feature pages, ads, emails, CTAs, popups — using conversion frameworks (AIDA, PAS, BAB, FAB), headline and CTA formulas, and a context-intake step before writing. Use whenever the deliverable is meant to move someone toward a decision, not for formal business documents (see tangison-documents) or plain informational writing.
---

# Tangison Copywriting

Copywriting is not creative writing — it's strategic writing designed to move someone toward a decision. Every piece must do four things: grab attention, create desire, remove friction, and prompt action. If it fails at any one, it fails, however well-written the sentences are.

This skill governs *persuasive* copy specifically. For formal business documents (quotations, proposals, contracts, reports), use `tangison-documents` instead — and either way, the base writing standards already set there (no em dashes, no generic AI buzzwords, natural voice, never fabricate proof points or stats) still apply; this skill adds the persuasion layer on top, it doesn't replace that foundation.

## Step 1 — Context intake (before writing)

Check for existing context first: a client's own brand/positioning docs if supplied, or — if the copy is for Tangison itself — the relevant entity's brand block in `tangison-documents` (Technologies / Studio / Labs). Only ask for what isn't already covered.

Gather:
1. **Piece type and goal** — homepage, landing page, pricing, feature, about, ad, email, CTA, popup — and the *one* primary action wanted from it.
2. **Audience** — who they are, the problem they're trying to solve, their objections/hesitations, and the actual words they use to describe their own problem.
3. **Offer** — what's being sold, what makes it different, the transformation/outcome, and what proof points genuinely exist (numbers, testimonials, case studies — never invent these).
4. **Traffic context** — where visitors arrive from, and what they already know before landing.

## Step 2 — Pick a framework

| Framework | Structure | Best for |
|---|---|---|
| AIDA | Attention → Interest → Desire → Action | Story-driven; ads, emails, editorial, general landing pages |
| PAS | Problem → Agitate → Solution | Direct-response; pain-aware audiences; sales pages |
| BAB | Before → After → Bridge | Transformation stories; testimonials; case studies |
| FAB | Feature → Advantage → Benefit | Product pages; feature lists; differentiation from competitors |
| 4 U's | Useful, Urgent, Unique, Ultra-specific | Headlines; subject lines |

**AIDA example:** "Spend 10 hours/week on client reporting? Automate it in 10 minutes." → elaborate the pain → paint the transformation → "Start your free 14-day trial — no credit card required."

**PAS example:** "Your outreach emails are getting ignored." → "Every unanswered email is a lost opportunity." → "Our 5-step cold email framework gets 23% reply rates."

**FAB example:** "Syncs with 12 data sources in real time." → "Unlike competitors that sync once daily, you never work with stale data." → "Make confident decisions faster."

## Step 3 — Core principles

- **Clarity over cleverness.** If forced to choose, choose clear. A confused reader doesn't convert, however clever the line.
- **Benefits over features.** Features are what it does; benefits are what that means for the customer. Lead with the latter.
- **Specificity over vagueness.** "Save time on your workflow" → "Cut weekly reporting from 4 hours to 15 minutes."
- **Customer language over company language.** Mirror how the audience actually describes their problem, not internal terminology.
- **One idea per section.** Each section advances a single argument; don't stack claims.
- **Information gain.** Copy that restates what competitors already say adds nothing. Lead with a unique angle, proprietary data, or a contrarian take — ask "what does this add that others don't?"
- **Honest over sensational.** Fabricated statistics or testimonials erode trust and create real liability — this is non-negotiable, not a style preference.

## Step 4 — Headline formulas

| Formula | Example |
|---|---|
| The Promise | "Double your email open rates in 30 days" |
| The Question | "Still wasting 10 hours/week on manual invoicing?" |
| The How-To | "How to automate your entire sales pipeline in one afternoon" |
| The Number | "7 mistakes killing your landing page conversions" |
| The Negative | "Stop losing leads to your broken signup flow" |
| The Curiosity Gap | "The one change that tripled our demo bookings" |
| The Transformation | "From 50 leads/month to 500 — here's what changed" |
| Before → After | "From 0 to 10K users in 90 days" |

Rules: be specific ("add $10K MRR in 90 days" beats "grow your business"); lead with the outcome, not the method; keep under ~60 characters if it also needs to work as an SEO title; avoid clickbait that the page doesn't deliver on.

## Step 5 — CTA copy

Formula: **[Action verb] + [What they get] + [Urgency or friction removal]**

Weak: "Submit," "Click here," "Learn more," "Sign Up" — generic, no motivation, no stated outcome.

Strong: "Start my free trial," "Get the complete checklist," "Reserve my spot before Friday," "See pricing for my team."

Placement: above the fold so acting doesn't require scrolling; after value has been explained, not before; repeated after each value section on long pages; one clear CTA per page — offering five options gets none of them picked.

## Step 6 — Emotional triggers

| Trigger | When to use | Example |
|---|---|---|
| Fear of missing out | Limited offers, scarcity | "Only 3 spots left this month" |
| Fear of loss | Cost of inaction is high | "Every day without this, you're losing X" |
| Desire for status | Aspirational, B2B | "Join 10,000+ top-performing agencies" |
| Desire for ease | Replacing manual work | "Set it up once. Forget about it forever." |
| Frustration | Replacing a broken solution | "Tired of tools that promise the world and deliver nothing?" |
| Hope | Outcome feels out of reach | "Yes, you can hit $10K MRR as a solo founder" |

Use emotion to hook, then use logic — features, proof, specifics — to justify the decision rationally.

## Step 7 — Handle objections

| Objection | Copy response |
|---|---|
| "Too expensive" | Show ROI: "Pays for itself in 2 weeks based on time saved" |
| "Won't work for me" | Social proof: "Here's how [similar customer] got results" |
| "No time to implement" | Ease claim: "Setup takes 10 minutes. We guide you through it." |
| "What if it doesn't work?" | Risk reversal: "30-day money-back guarantee" |
| "Need to think about it" | Genuine urgency/scarcity only — never fabricated |

Place objection-handling in an FAQ section, inside real testimonials, and right before the CTA.

## Step 8 — Proof

Types: testimonials (name, title, company — specificity is credibility), case studies (problem → action → specific outcome), data (numbers, percentages, time/revenue), social proof (customer counts, press mentions), credentials. Every one of these must be real — never invented, per the honesty principle above. Sprinkle proof throughout the page rather than dumping it in one section.

## Step 9 — Page structure

**Above the fold:** headline (the single most important message, specific over generic) → subheadline (expands, adds specificity, 1–2 sentences) → primary CTA (action-oriented, states what they get).

**Core sections, roughly in order:**

| Section | Purpose |
|---|---|
| Social proof | Build credibility |
| Problem/pain | Show you understand their situation |
| Solution/benefits | Connect to outcomes (3–5 key benefits) |
| How it works | Reduce perceived complexity (3–4 steps) |
| Objection handling | FAQ, comparisons, guarantees |
| Final CTA | Recap value, repeat CTA, risk reversal |

**Page-type notes:**
- **Homepage** — serve multiple audiences without going generic; lead with the broadest value proposition; give clear paths for different visitor intents.
- **Landing page** — single message, single CTA, headline matches the traffic source it came from, complete argument on one page.
- **Pricing page** — help visitors self-select the right plan; address "which is right for me?"; make the recommended plan obvious.
- **Feature page** — connect feature → benefit → outcome; show real use cases.
- **About page** — tell the actual story; connect mission to customer benefit; still needs a CTA.

## Step 10 — Voice and tone

Establish before writing: formality level (casual, professional-but-friendly, formal/enterprise) and brand personality (playful vs serious, bold vs understated, technical vs accessible). Stay consistent but adjust intensity: headlines can be boldest, body copy should be clearest, CTAs should be most action-oriented.

## Writing style rules

Simple over complex ("use" not "utilize"). Specific over vague (avoid "streamline," "optimize," "innovative" as unsupported claims). Active over passive. Confident over qualified (cut "almost," "very," "really"). Show over tell. Rhetorical questions and analogies are useful when they clarify, not when they're just decoration.

## Quick quality check before delivering

- Any jargon that would confuse an outsider?
- Any sentence trying to do too much?
- Passive voice constructions?
- Exclamation points? (remove them)
- Buzzwords without substance?
- Every claim, stat, or testimonial real and sourced — nothing invented to fill a gap?

## Output format

- **Page copy**, organized by section: headline, subheadline, CTA, section headers and body, secondary CTAs.
- **2–3 headline and CTA options**, each with a one-line rationale for why it works.
- **Meta content** if relevant: page title, meta description.
- For a full landing page or site build, hand off completed copy to `tangison-full-output-enforcement` discipline — every section gets real, finished copy, never a placeholder or "similar copy for the remaining sections."

## Testing and iteration

Change one variable at a time — headline, CTA, or structure — never several at once, or the result can't be attributed to anything. Run version A against version B to equal traffic for 7–14 days or until significance, keep the winner, test the next variable against it. Headlines usually have the biggest impact; test those first.

## Common mistakes

Writing about features instead of benefits. Being clever instead of clear. Burying the value below the fold. Jargon and buzzwords standing in for substance. Multiple competing CTAs instead of one clear one. Writing in the brand's language instead of the audience's. Fabricating a stat, testimonial, or urgency claim to make the copy land harder — always the fastest way to destroy trust once caught.
