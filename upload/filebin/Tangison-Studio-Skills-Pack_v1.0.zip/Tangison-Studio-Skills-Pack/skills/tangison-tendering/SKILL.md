---
name: tangison-tendering
description: Build, research, write, review, structure, price, format, and QC professional tenders, RFPs, RFQs, EOIs, bids, proposals, compliance schedules, and supporting tender documents. Use for tender strategy, procurement research, compliance analysis, technical and commercial responses, legal and contractual review, evidence management, and final submission preparation.
---

# Tangison Tendering

A tender is not simply a document. It is a compliance, evidence, technical, legal, commercial, and persuasion exercise.

The objective is to produce a submission that is accurate, compliant, credible, evidence-led, commercially sound, easy to evaluate, and professionally presented.

Core workflow:

Understand -> Research -> Qualify -> Strategize -> Map compliance -> Build evidence -> Draft -> Review -> Format -> QC -> Submit

## 1. Tender intake

Before writing, inspect the complete tender or procurement package.

Identify:

- Procuring entity
- Tender reference
- Scope of work
- Eligibility requirements
- Mandatory requirements
- Evaluation criteria
- Technical requirements
- Commercial requirements
- Submission instructions
- Required forms
- Required certificates
- Required declarations
- Required experience
- Key personnel requirements
- Pricing requirements
- Contract conditions
- Deadline
- Delivery or submission method
- File and naming requirements

Do not begin drafting from a partial understanding of the tender.

## 2. Tender intelligence

Read the tender as an evaluator would.

Determine:

- What problem is the client trying to solve?
- What outcome is required?
- What will determine technical compliance?
- What will determine commercial competitiveness?
- What evidence will strengthen the submission?
- What could disqualify the bidder?
- What requirements are ambiguous?
- What risks exist?
- What information is missing?

Separate mandatory requirements from desirable qualities.

Never assume that an attractive proposal can compensate for a mandatory compliance failure.

## 3. Research

Research only what materially improves the tender.

Research may include:

- Procuring institution
- Institutional mandate
- Operating environment
- Applicable legislation
- Procurement rules
- Technical standards
- Industry conditions
- Existing systems
- Relevant technologies
- Project context
- Market conditions
- Comparable solutions
- Credible implementation practices

Use reliable sources.

Record important sources and distinguish:

- Verified fact
- Source-supported interpretation
- Professional judgement
- Assumption
- Unknown

Never turn an assumption into a fact.

Never invent statistics, market data, project history, partnerships, clients, certifications, awards, testimonials, technical capabilities, or institutional facts.

## 4. Compliance matrix

Build a compliance matrix before final drafting.

| Requirement | Mandatory | Response | Evidence | Location |
|---|---|---|---|---|
| Requirement | Yes/No | Response | Supporting evidence | Section/Annexure |

Every mandatory requirement must have:

1. A clear response.
2. Supporting evidence where required.
3. A traceable location in the submission.

Do not rely on memory.

## 5. Tender strategy

Determine the strongest legitimate position before writing.

Assess:

- Lead bidder role
- Consortium or JV structure
- Subcontractor role
- Technical capability
- Relevant experience
- Corporate credentials
- Compliance credentials
- Personnel
- Delivery capacity
- Financial capacity
- Commercial position
- Technology
- Implementation approach
- Risks
- Gaps
- Available evidence

Build the response around the evaluation criteria.

Do not write a generic company profile and expect it to become a tender response.

## 6. Tangison credentials

Use Tangison credentials as evidence, not decoration.

The current verified credential base may include:

- Tangison Technologies CC
- Registration: CC/2026/10147
- Namibian ownership
- AI and technology specialisation
- VAT registration
- SME status
- Insurance cover
- Audited financial statements
- Relevant AI and software development capability
- Documented project experience
- Relevant technical personnel

Only include a credential when it is current, relevant, and supported by evidence.

If a certificate, reference, project, partnership, number, award, qualification, or capability cannot be verified, do not present it as fact.

## 7. Tender writing

Write like a competent professional responding to a procurement evaluation.

The character should be:

- Precise
- Direct
- Professional
- Institutional
- Technical where necessary
- Commercially aware
- Evidence-led
- Confident without exaggeration
- Natural
- Easy to evaluate

Prefer:

"We will configure, deploy, test, document, and support the system."

Over:

"We will deliver a world-class, innovative, transformative solution that seamlessly revolutionizes operations."

The first communicates execution.

The second communicates nothing measurable.

## 8. No AI sounding language

Do not use language simply because it sounds corporate or sophisticated.

Avoid unsupported phrases such as:

- World-class
- Cutting-edge
- Revolutionary
- Game-changing
- Seamless
- Unparalleled
- Best-in-class
- Transformative
- Holistic
- Robust and scalable
- Innovative solutions
- Leverage synergies
- Unlock value
- Empower stakeholders

Use specific descriptions instead.

Every important claim should answer:

What exactly?
For whom?
How?
Under what conditions?
Supported by what evidence?

Do not use em dashes.

Do not use fake sophistication.

Do not pad paragraphs.

Do not repeat the same claim in different words.

## 9. Technical response

Map every technical response directly to the specification.

For each major requirement explain, where appropriate:

- Requirement
- Proposed approach
- Technical method
- Deliverable
- Implementation
- Responsibility
- Verification
- Support

Use tables where they improve evaluation.

Do not add technical complexity merely to make the proposal appear advanced.

The best technical response is understandable, specific, feasible, and supported by evidence.

## 10. Legal and contractual review

Review the tender and proposed response for:

- Obligations
- Liability
- Indemnities
- Warranties
- Intellectual property
- Confidentiality
- Data protection
- Payment
- Termination
- Penalties
- Service levels
- Insurance
- Performance security
- Subcontracting
- Consortium obligations
- Dispute resolution
- Governing law
- Contract conflicts
- Unacceptable commercial exposure

Identify issues clearly.

Do not invent legal conclusions.

Where professional legal advice is required, flag the issue for legal review.

Never silently accept a material contractual risk simply because it makes the tender easier to submit.

## 11. Commercial review

Check every commercial figure independently.

Verify:

- Quantities
- Unit prices
- Subtotals
- Discounts
- VAT
- Total
- Total in words
- Pricing assumptions
- Validity period
- Milestones
- Payment terms
- Exclusions
- Inclusions
- Technical scope against price

Technical scope and commercial scope must agree.

Never invent a price to complete a blank field.

Never change a commercial figure without authority.

## 12. Evidence management

Every major claim should have an evidence basis.

Evidence may include:

- Certificates
- Registration documents
- Audited financial statements
- Insurance
- Project references
- Contracts
- Completion records
- Client references
- CVs
- Qualifications
- Technical documentation
- Case studies
- System demonstrations
- Policies
- Declarations

Use the strongest relevant evidence.

Do not overload the tender with irrelevant attachments.

## 13. Document architecture

Follow the procuring entity's required structure whenever one is prescribed.

Where no structure is prescribed, a suitable structure may include:

1. Submission letter
2. Executive summary
3. Company information
4. Understanding of requirements
5. Proposed solution
6. Methodology
7. Implementation plan
8. Technical architecture
9. Project governance
10. Team and key personnel
11. Relevant experience
12. Risk management
13. Support and SLA
14. Commercial proposal
15. Compliance matrix
16. Declarations
17. Annexures

Do not force this structure onto a tender that requires another format.

## 14. Document design

Tender documents should be designed for evaluation first.

Priorities:

- Clear hierarchy
- Readability
- Consistent typography
- Strong tables
- Logical spacing
- Easy navigation
- Correct page numbering
- Clear sectioning
- Professional letterhead
- Correct entity information
- Accurate signatures
- Clean annexures

Use authentic supplied logos and brand assets.

Do not redraw or invent logos.

Do not redesign an existing tender document unnecessarily.

Preserve intentional structure and make surgical improvements where needed.

## 15. Letterheads and formal documents

When letterhead is required:

- Use the correct issuing entity.
- Use the supplied authentic letterhead.
- Use a real repeating Word header and footer where applicable.
- Remove duplicate typed header information from the body.
- Preserve the intended logo placement.
- Preserve registration information.
- Preserve contact information.
- Maintain consistent footer treatment.
- Confirm the header and footer repeat after PDF conversion.

Never create a different letterhead style for every document in the same tender pack without a reason.

## 16. Copyright and intellectual property

Protect Tangison-created material appropriately.

This may include:

- Original tender methodology
- Technical approaches
- Architecture
- Diagrams
- Original written material
- Proprietary processes
- Templates
- Research compilations
- Software concepts
- Original schedules

Do not claim ownership over material belonging to:

- The procuring entity
- Government institutions
- Third parties
- Public legislation
- Public tender documents
- Licensed content
- Client-provided material

Use copyright and confidentiality notices where appropriate.

Do not use aggressive or unnecessary copyright language that could conflict with procurement requirements.

## 17. Tender character

A Tangison tender should feel:

Serious.
Prepared.
Competent.
Specific.
Namibian where relevant.
Technically capable.
Commercially responsible.
Evidence-led.
Easy to evaluate.

It should never feel:

- Artificial
- Over-designed
- Desperate
- Generic
- Inflated
- Repetitive
- AI-generated
- Unsupported
- Overly promotional

The document should make the evaluator's job easier.

## 18. Quality control

Before delivery, perform separate audits.

### Compliance audit

- Every mandatory requirement answered.
- Every required form included.
- Every required declaration included.
- Every required certificate included.
- All signatures present.
- All dates correct.
- Submission instructions followed.

### Evidence audit

- Claims supported.
- Credentials verified.
- References genuine.
- Certificates current.
- No fabricated proof.

### Technical audit

- Scope fully addressed.
- Methodology feasible.
- Deliverables defined.
- Personnel appropriate.
- Implementation realistic.
- Support requirements addressed.

### Legal audit

- Material obligations reviewed.
- Contract risks identified.
- IP provisions reviewed.
- Liability reviewed.
- Confidentiality reviewed.
- Termination reviewed.

### Commercial audit

- Calculations correct.
- VAT correct.
- Totals correct.
- Totals in words correct.
- Pricing matches scope.
- Assumptions identified.

### Document audit

- Correct entity.
- Correct logo.
- Correct letterhead.
- Correct registration details.
- Consistent formatting.
- No broken tables.
- No orphaned headings.
- No split signature blocks.
- No blank pages.
- No stretched justified lines.
- Page numbering correct.

## 19. Final render

Never assume a DOCX is finished because the source file looks correct.

Render the final document to PDF.

Inspect every page.

Check:

- Headers
- Footers
- Logos
- Margins
- Tables
- Page breaks
- Signatures
- Typography
- Images
- Page numbering
- Whitespace
- Alignment
- Orphans
- Split rows
- Blank pages

If a visual problem appears, correct the source document and render again.

Do not deliver an unverified document.

## 20. Multi-document tender packs

For multiple-document submissions:

1. Establish the document list.
2. Establish the required order.
3. Identify the issuing entity for each document.
4. Apply the appropriate letterhead.
5. Process each document individually.
6. Render each document.
7. QC each document.
8. Verify filenames.
9. Verify page counts.
10. Verify the final combined pack.
11. Check that no document is missing.
12. Check that no outdated version is included.

Never batch-edit a tender pack blindly.

## 21. Final acceptance test

A tender is ready only when:

- It is compliant.
- It is accurate.
- It is evidence-supported.
- It is technically credible.
- It is commercially reconciled.
- Material legal risks have been reviewed.
- The writing is natural and precise.
- No unsupported claims remain.
- No AI-sounding filler remains.
- No em dashes remain.
- The documents render correctly.
- The final submission matches the procurement instructions.

The standard is not "looks good."

The standard is:

**Correct. Compliant. Defensible. Evidence-led. Evaluator-ready.**
