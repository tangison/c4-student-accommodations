---
name: tangison-systematic-debugging
description: Mandatory root-cause debugging methodology for ANY technical issue — test failures, production bugs, unexpected behavior, performance problems, build failures, integration issues. Check for this skill BEFORE proposing a fix, before guessing, and before exploring code "just to get oriented" — symptom patching without root-cause investigation is a hard failure, not a shortcut. Use this especially under time pressure, when a fix seems obvious, when a previous fix didn't work, or when the issue seems too simple to bother — simple bugs have root causes too.
---

# Tangison Systematic Debugging

## The Iron Law

**NO FIXES WITHOUT ROOT CAUSE INVESTIGATION FIRST.** If Phase 1 isn't complete, no fix gets proposed. Symptom fixes are failure, not progress.

## Before you start

When a task is a bug or technical issue, this skill runs before any implementation skill, and before exploring the codebase "just to see what's there." Checking for a relevant skill happens before clarifying questions, before a quick file check, before anything that looks like productive motion — those are all real work, and this is the skill that governs how to do that work correctly. State plainly what you're doing: "Using systematic-debugging to diagnose X," then work the phases in order.

This is a strong default for technical work, not a suspension of judgment — if a request plainly isn't a debugging task, or the user has told you directly to skip the process, don't force it in.

## When to use

Any technical issue: test failures, production bugs, unexpected behavior, performance problems, build failures, integration issues.

Especially when: under time pressure, when "just one quick fix" seems obvious, when multiple fixes have already been tried, when a previous fix didn't work, when you don't fully understand the issue.

Don't skip because: the issue seems simple (simple bugs have root causes too), you're in a hurry (rushing guarantees rework), or someone wants it fixed now (systematic is faster than thrashing).

## Phase 1: Root cause investigation

Before attempting any fix:

- **Read errors carefully.** Full stack traces, line numbers, file paths, error codes — they often contain the exact answer.
- **Reproduce consistently.** Can you trigger it reliably, with exact steps, every time? If not reproducible, gather more data — don't guess.
- **Check recent changes.** Git diff, recent commits, new dependencies, config or environment differences.
- **Gather evidence in multi-component systems.** When the system spans multiple components (CI → build → signing, API → service → database), add diagnostic instrumentation at each boundary before proposing fixes: log what enters and exits each component, verify environment/config propagation, check state at each layer. Run once, gather evidence showing *where* it breaks, then investigate that specific component.
- **Trace data flow.** When the error is deep in a call stack: where does the bad value originate, what called this with the bad value, keep tracing up until you find the source. Fix at the source, not the symptom.

## Phase 2: Pattern analysis

- **Find working examples.** Locate similar working code in the same codebase — what works that's similar to what's broken?
- **Compare against references completely.** If implementing a known pattern, read the reference implementation fully — not skimmed.
- **List every difference**, however small. Don't assume something can't matter.
- **Understand dependencies** — what other components, settings, config, or assumptions does this need?

## Phase 3: Hypothesis and testing

- **Form a single hypothesis.** State it clearly: "I think X is the root cause because Y." Be specific, not vague.
- **Test minimally.** Smallest possible change, one variable at a time. Don't fix multiple things at once.
- **Verify before continuing.** Worked → Phase 4. Didn't work → form a new hypothesis, don't stack another fix on top.
- **When you don't know, say so.** "I don't understand X" beats pretending to know. Ask, or research more.

## Phase 4: Implementation

- **Create a failing test case first** — simplest possible reproduction, automated if the project has a test framework, a one-off script if not. Required before fixing.
- **Implement a single fix** addressing the root cause. One change at a time. No "while I'm here" improvements, no bundled refactoring.
- **Verify the fix** with real evidence: test passes, no other tests broken, issue actually resolved. This is the same standard as the standing PROOF.md convention — a fetched, run, or rendered result, never a self-reported "should work now."
- **If the fix doesn't work: stop and count.**
  - Fewer than 3 attempts → return to Phase 1 with the new information.
  - 3 or more attempts → stop. Do not attempt fix #4. Go to "Question the architecture" below.

### When 3+ fixes have failed: question the architecture

Signs this is architectural, not a bad hypothesis: each fix reveals new shared state or coupling somewhere else, fixes keep requiring "massive refactoring," each fix creates a new symptom elsewhere.

Stop and ask: is this pattern fundamentally sound, or is it being kept through inertia? Should the architecture change instead of patching further? Raise this with your human partner before attempting another fix — this is a wrong-architecture signal, not a failed-hypothesis signal.

## Red flags — stop and return to Phase 1

"Quick fix for now, investigate later." · "Just try changing X and see." · "Add multiple changes, run tests." · "Skip the test, I'll manually verify." · "It's probably X, let me fix that." · "I don't fully understand but this might work." · "Pattern says X but I'll adapt it differently." · Listing fixes without investigation. · Proposing a solution before tracing data flow. · "One more fix attempt" after 2+ failures. · Each fix reveals a new problem somewhere else.

Signals from a human partner that you're doing it wrong: "Is that not happening?" (you assumed without verifying) · "Will it show us...?" (you should have added evidence gathering) · "Stop guessing." · "We're stuck?" (your approach isn't working).

## Common rationalizations

| Excuse | Reality |
|---|---|
| "Issue is simple, don't need process" | Simple issues have root causes too. Process is fast for simple bugs. |
| "Emergency, no time for process" | Systematic debugging is faster than guess-and-check thrashing. |
| "Just try this first, then investigate" | The first fix sets the pattern — do it right from the start. |
| "I'll write the test after confirming the fix works" | Untested fixes don't stick. Test first proves it. |
| "Multiple fixes at once saves time" | Can't isolate what worked. Causes new bugs. |
| "Reference is too long, I'll adapt the pattern" | Partial understanding guarantees bugs. Read it completely. |
| "I see the problem, let me fix it" | Seeing symptoms isn't the same as understanding root cause. |
| "One more fix attempt" (after 2+ failures) | 3+ failures means an architectural problem — question the pattern, don't fix again. |

## Quick reference

| Phase | Key activities | Success criteria |
|---|---|---|
| 1. Root cause | Read errors, reproduce, check changes, gather evidence | Understand what and why |
| 2. Pattern | Find working examples, compare completely | Identify every difference |
| 3. Hypothesis | Form one theory, test minimally | Confirmed, or a new hypothesis |
| 4. Implementation | Failing test, single fix, verify with evidence | Bug resolved, tests pass |

## When the process reveals "no root cause"

If systematic investigation genuinely shows the issue is environmental, timing-dependent, or external: the process is complete. Document what was investigated, implement appropriate handling (retry, timeout, clear error message), add monitoring for future recurrence. But treat this conclusion skeptically — most "no root cause" calls are an incomplete investigation, not an absent one.
