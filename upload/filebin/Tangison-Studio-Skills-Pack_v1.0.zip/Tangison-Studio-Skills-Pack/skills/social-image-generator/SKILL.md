---
name: social-image-generator
description: "Generate professional marketing images — social media posts, flyers, event posters, promotional banners, and content calendars — using the eachsense image API. Use this skill whenever the user mentions a post, flyer, poster, ad, banner, campaign, Instagram, Facebook, WhatsApp image, or wants to plan their social content. Use it even if they just say 'make something for my business' or 'I need content for next month' — this skill handles both single images and full Namibia-aware content calendar planning."
metadata:
  starchild:
    emoji: "🎨"
    skillKey: social-image-generator
    requires:
      env: [EACHLABS_API_KEY]
---

# Social Image Generator

Create any marketing image or content plan via the eachsense API. Covers social posts, flyers, event posters, campaign series, and monthly content calendars — with built-in Namibian context.

---

## Step 1 — Diagnose the request

If the request has enough detail, skip directly to Step 2. Otherwise ask ONE question:

> "Is this for a specific event or offer, a regular brand post, or do you want a full content plan for the month?"

**Route map:**

| They want | Do this |
|---|---|
| One image (post, flyer, poster) | Collect 4 details → build prompt → generate |
| A series (carousel, campaign) | Collect details → generate with shared `session_id` |
| Content calendar / monthly plan | Read `references/namibia-calendar.md` → present plan → offer to generate each image |

---

## Step 2 — Collect the 4 essentials

Before generating, you need:

1. **Purpose** — What is this promoting? (event, product, service, awareness)
2. **Format** — What size/platform? (see format table below)
3. **Brand** — Brand name + 1–2 colors (or mood if no colors yet)
4. **Mode** — Draft or final? (`eco` = fast, `max` = print-ready)

If any are missing, ask for them all in one message. Don't generate blind.

---

## Step 3 — Build the prompt

Use this formula every time:

```
Create a [FORMAT RATIO] [TYPE] for [BRAND NAME].
[VISUAL SUBJECT — what is shown, composition, mood].
[COLOR PALETTE — exact brand colors or mood: warm/cool/bold/earthy/Pan-African].
[STYLE — modern, vibrant, professional, minimal, patriotic, luxury, etc.].
Leave space at [TOP / BOTTOM / CENTER] for [headline / logo / contact / offer text].
```

Non-negotiables: always include ratio, subject, color direction, and text space location. Missing any one of these degrades output quality significantly.

---

## Step 4 — Call the API

```bash
./scripts/generate.sh "<prompt>" "<mode>" "<session_id>"
```

Or construct the call directly:

```
POST https://eachsense-agent.core.eachlabs.run/v1/chat/completions
Content-Type: application/json
X-API-Key: $EACHLABS_API_KEY
Accept: text/event-stream

{
  "model": "eachsense/beta",
  "stream": true,
  "mode": "max",
  "session_id": "brand-campaign-slug",
  "messages": [{ "role": "user", "content": "<prompt>" }]
}
```

`session_id` rule: Required for any series or iteration. Format: `brandname-campaigntype-monthyear`. First call establishes the visual style; subsequent calls inherit it automatically.

---

## Format reference

| Output needed | Ratio | Pixels |
|---|---|---|
| Instagram feed (square) | 1:1 | 1080×1080 |
| Instagram / Facebook portrait | 4:5 | 1080×1350 |
| Story / Reel / TikTok | 9:16 | 1080×1920 |
| Facebook cover | 16:9 | 1920×1080 |
| Standard flyer / A4 | 2:3 | 2480×3508 |
| Event poster | 11:17 | 1100×1700 |
| WhatsApp broadcast image | 1:1 | 1080×1080 |

---

## Content calendar mode

When the user wants a monthly or weekly plan, load the full calendar reference:

→ Read `references/namibia-calendar.md`

It contains:
- 12-month Namibia campaign calendar (public holidays, cultural moments, seasonal triggers)
- Weekly rhythm template (Mon–Sun post types)
- Ready-to-use image prompts for every major occasion
- Always-on content templates (motivation, testimonials, BTS, product highlights)

Present the plan first. Then ask: "Want me to generate the images for any of these?"

---

## Series and iteration

```
# Draft (fast, cheap)
mode: "eco"   session_id: "brand-draft-001"

# Refine
"Make it more vibrant and bold"  →  same session_id

# Final
mode: "max"   session_id: "brand-final-001"

# Variations
"Create 2 more versions — one minimal, one bold"  →  same session_id
```

---

## Style vocabulary

Load `references/styles-and-formats.md` when the user has not specified a visual direction and needs suggestions. Contains style descriptions, Namibian visual references, and prompt language for 8 distinct aesthetics.

---

## Error handling

| Error | Cause | Fix |
|---|---|---|
| HTTP 422 | Insufficient balance | Top up at eachlabs.ai |
| Content policy | Restricted content in prompt | Remove flagged elements, re-prompt |
| Timeout | Complex generation | Set client timeout to 10 min minimum |
